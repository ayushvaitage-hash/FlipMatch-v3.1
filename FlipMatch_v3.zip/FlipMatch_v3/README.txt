FLIP MATCH v3.1  -  Developed & created by Ayush Vaitage

BUILD: upload this zip to GitHub (see chat steps) or open the folder in Android Studio.
UPDATES: put update.json in your GitHub repo root, then UPDATE_URL is already set to ayushvaitage-hash/flipmatch in
  app/src/main/java/com/flipmatch/game/Updater.java
  (https://raw.githubusercontent.com/USER/REPO/main/update.json)
Raise "versionCode" in update.json to show the update popup. "announcementId" shows news once per id.
