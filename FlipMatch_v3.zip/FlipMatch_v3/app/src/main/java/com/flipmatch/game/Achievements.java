package com.flipmatch.game;

import java.util.ArrayList;

/** Ten simple achievements; progress is derived from counters stored in Settings. */
final class Achievements {
    private Achievements() {}

    static final int COUNT = 10;
    static final String[] NAMES = {
            "FIRST STEPS", "COMBO MASTER", "STAR COLLECTOR", "LEVEL HOPPER", "GRAVITY SURFER",
            "HIGH SCORER", "DEDICATED", "PERFECTIONIST", "HARDEST HERO", "DAILY FAN"};
    static final String[] DESC = {
            "Clear your first level", "Reach a x5 combo", "Collect 30 stars", "Clear 10 levels", "Flip gravity 25 times",
            "Score 3000 in Endless", "Play 25 games", "Get 3 stars on 5 levels", "Clear a level on HARDEST", "Claim the daily reward 3 days in a row"};
    static final int[] TARGET = {1, 5, 30, 10, 25, 3000, 25, 5, 1, 3};

    private static int completed() {
        int n = 0;
        for (int i = 0; i < Settings.LEVEL_COUNT; i++) {
            if (Settings.stars[i] > 0) {
                n++;
            }
        }
        return n;
    }

    private static int threeStars() {
        int n = 0;
        for (int i = 0; i < Settings.LEVEL_COUNT; i++) {
            if (Settings.stars[i] >= 3) {
                n++;
            }
        }
        return n;
    }

    static int progress(int i) {
        switch (i) {
            case 0:
                return Math.min(1, completed());
            case 1:
                return Settings.bestCombo;
            case 2:
                return Settings.totalStars();
            case 3:
                return completed();
            case 4:
                return Settings.cntFlips;
            case 5:
                return Settings.maxEndless;
            case 6:
                return Settings.cntGames;
            case 7:
                return threeStars();
            case 8:
                return Settings.hardWin ? 1 : 0;
            default:
                return Settings.maxStreak;
        }
    }

    /** Unlocks whatever just became true and returns the new indices (empty list if none). */
    static ArrayList<Integer> check() {
        ArrayList<Integer> fresh = new ArrayList<Integer>();
        for (int i = 0; i < COUNT; i++) {
            if (!Settings.ach[i] && progress(i) >= TARGET[i]) {
                Settings.ach[i] = true;
                fresh.add(i);
            }
        }
        if (!fresh.isEmpty()) {
            Settings.save();
        }
        return fresh;
    }

    static int doneCount() {
        int n = 0;
        for (int i = 0; i < COUNT; i++) {
            if (Settings.ach[i]) {
                n++;
            }
        }
        return n;
    }
}
