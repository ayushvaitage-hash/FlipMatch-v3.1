package com.flipmatch.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public final class GameView extends View {

    @Deprecated
    public static final int CLEAR = 3;

    @Deprecated
    public static final int FALL = 4;

    @Deprecated
    public static final int FLIP = 5;

    @Deprecated
    public static final int IDLE = 0;

    @Deprecated
    public static final int OVER = 7;

    @Deprecated
    public static final int SHUFFLE = 6;

    @Deprecated
    public static final int SWAP = 1;

    @Deprecated
    public static final int SWAPBACK = 2;
    private final Paint addPaint;
    private float arrowAngle;
    private final Paint arrowGlow;
    private final Paint arrowPaint;
    private final Path arrowPath;
    private float bannerT;
    private String bannerText;
    private final int[] baseC;
    private int best;
    private int bestStart;
    private final Paint bgPaint;
    private Shader bgShader;
    private float bl;
    private final int[] blobColors;
    private final Paint[] blobPaints;
    private Glass boardGlass;
    private float boardW;
    private final float[] bokehS;
    private final float[] bokehV;
    private final float[] bokehX;
    private final float[] bokehY;
    private float bt;
    private Glass cardBest;
    private Glass cardGravity;
    private Glass cardMoves;
    private Glass cardScore;
    private float cell;
    private final Paint cellPaint;
    private int combo;
    private final int[] darkC;
    private float displayScore;
    private final float dp;
    private final Paint[] fillPaints;
    private float flash;
    private int flipEvery;
    private boolean flipMid;
    private float flipSy;
    private final Paint glassEdge;
    private final Paint glassFill;
    private final Paint glossBottom;
    private final Paint glossTop;
    private final Paint[] glowPaints;
    private boolean gravityDown;
    private final Tile[][] grid;
    private boolean handled;
    private int[] hint;
    private float idleT;
    private int lastFlip;
    private long lastNanos;
    private final int[] lightC;
    private final boolean[][] marked;
    private int moveCount;
    private int moves;
    private final int n;
    private boolean newBest;
    private Glass overGlass;
    private float overT;
    private final ArrayList<Particle> particles;
    private int phase;
    private float phaseDur;
    private final Paint plain;
    private final ArrayList<Popup> popups;
    private final SharedPreferences prefs;
    private final Paint rimPaint;
    private final Paint ringPaint;
    private final Random rnd;
    private int sC1;
    private int sC2;
    private int sR1;
    private int sR2;
    private int score;
    private float scorePop;
    private int selC;
    private int selR;
    private final SoundFx sfx;
    private final Paint shadowRect;
    private float shake;
    private final Path[] shapes;
    private Glass soundGlass;
    private final Paint sparkle;
    private int startC;
    private int startMoves;
    private int startR;
    private float startX;
    private float startY;
    private float t;
    private final Paint textPaint;
    private final Paint tileShadow;
    private float time;
    private Shader titleShader;
    private float titleY;
    private final int types;

    private static final int S_HOME = 0;
    private static final int S_LEVELS = 1;
    private static final int S_SETTINGS = 2;
    private static final int S_GAME = 3;
    private static final int ID_PLAY = 1;
    private static final int ID_ENDLESS = 2;
    private static final int ID_SETTINGS = 3;
    private static final int ID_DIFF = 4;
    private static final int ID_BACK = 10;
    private static final int ID_G_MENU = 30;
    private static final int ID_G_SOUND = 31;
    private static final int ID_G_RESTART = 32;
    private static final int ID_O_LEFT = 40;
    private static final int ID_O_RIGHT = 41;
    private static final int ID_O_SHARE = 42;
    private static final int ID_P_OK = 50;
    private static final int ID_P_CANCEL = 51;
    private static final int ID_INSTA = 60;
    private static final int ID_SHARE_APP = 61;
    private static final int ID_UPDATE = 62;
    private static final int ID_HOME_ACH = 5;
    private static final int ID_HOME_ABOUT = 6;
    private static final int S_ABOUT = 4;
    private static final int S_ACH = 5;
    private static final int BTN_ABOUT = 232;
    private static final int BTN_CHECK = 233;
    private static final int BTN_CARD = 234;
    private static final float TRANS_DUR = 0.42f;
    private static final String INSTA_URL = "https://www.instagram.com/ayushvaitage?vrfl=MWlnaDZyaHBuODU1dA==";
    private static final int ID_LEVEL0 = 100;
    private static final int SW_FLIP = 201;
    private static final int SW_HINTS = 202;
    private static final int SW_SOUND = 203;
    private static final int SW_HAPTIC = 204;
    private static final int SW_SHAKE = 205;
    private static final int SW_BG = 206;
    private static final int SL_SPEED = 211;
    private static final int SL_VOL = 212;
    private static final int SL_PART = 213;
    private static final int SEG_DIFF = 221;
    private static final int SEG_THEME = 222;
    private static final int BTN_RESET = 231;
    private static final int[] ROW_KIND = {0, 3, 1, 1, 2, 0, 1, 2, 1, 1, 0, 3, 2, 1, 0, 4, 4, 0, 4, 5};
    private static final int[] ROW_ID = {0, SEG_DIFF, SW_FLIP, SW_HINTS, SL_SPEED, 0, SW_SOUND, SL_VOL, SW_HAPTIC, SW_SHAKE, 0, SEG_THEME, SL_PART, SW_BG, 0, BTN_ABOUT, BTN_CHECK, 0, BTN_RESET, BTN_CARD};
    private static final String[] ROW_LABEL = {"GAMEPLAY", "DIFFICULTY", "GRAVITY FLIP", "HINTS", "GAME SPEED", "AUDIO & FEEL", "SOUND EFFECTS", "VOLUME", "HAPTICS", "SCREEN SHAKE", "VISUALS", "THEME", "PARTICLES", "BACKGROUND FX", "MORE", "ABOUT & INSTAGRAM", "CHECK FOR UPDATES", "DATA", "RESET PROGRESS", "ABOUT"};
    private static final int[] DIFF_COL = {0xFF2EE6A0, 0xFF2EB8FF, 0xFFFF9F43, 0xFFFF4D6D};
    private static final int[] THEME_COL = {0xFF2EB8FF, 0xFFFF7A3D, 0xFF00D4C8, 0xFFFF2BD6};

    private int screen = S_HOME;
    private float screenAge;
    private int mode;
    private int curLevel;
    private int activeTypes = 6;
    private int levelTarget;
    private float hintDelay = 4.0f;
    private boolean levelWon;
    private int starsEarned;
    private int starsShown;
    private Glass menuGlass;
    private Glass restartGlass;
    private final int[] themeBg = new int[3];
    private float uiDt = 0.016f;
    private int pressId;
    private boolean pressInside;
    private final float[] pressAnim = new float[512];
    private final int[] hitIds = new int[96];
    private final float[] hitRect = new float[96 * 4];
    private int hitCount;
    private final float[] rowAnim = new float[256];
    private final float[] wiggle = new float[Settings.LEVEL_COUNT];
    private final float[] rowTop = new float[ROW_KIND.length];
    private final float[] rowH = new float[ROW_KIND.length];
    private float scrollY;
    private float scrollVel;
    private float contentH;
    private float listTop;
    private float listBottom;
    private float setDownX;
    private float setDownY;
    private float setLastY;
    private long setLastT;
    private boolean setMoved;
    private boolean touching;
    private int activeRow = -1;
    private boolean resetArmed;
    private float resetArmT;
    private final RectF ctl = new RectF();
    private final RectF tmp = new RectF();
    private final RectF tmp2 = new RectF();


    public GameView(Context context) {
        super(context);
        this.n = 8;
        this.types = 6;
        this.startMoves = 30;
        this.flipEvery = 5;
        this.dp = getResources().getDisplayMetrics().density;
        this.lightC = new int[]{-25942, -7350017, -5832776, -2659, -1855233, -14442};
        this.baseC = new int[]{-53931, -14774017, -14690721, -15360, -6079233, -34278};
        this.darkC = new int[]{-7467218, -16040820, -16094413, -6657536, -11923572, -7390720};
        int i = this.n;
        Tile[][] tileArr = new Tile[i][];
        for (int i2 = 0; i2 < i; i2++) {
            tileArr[i2] = new Tile[this.n];
        }
        this.grid = tileArr;
        int i3 = this.n;
        boolean[][] zArr = new boolean[i3][];
        for (int i4 = 0; i4 < i3; i4++) {
            zArr[i4] = new boolean[this.n];
        }
        this.marked = zArr;
        this.rnd = new Random();
        this.prefs = context.getSharedPreferences("flipmatch", 0);
        this.sfx = new SoundFx();
        this.gravityDown = true;
        this.moves = this.startMoves;
        this.combo = 1;
        this.flipSy = 1.0f;
        this.bannerText = "";
        this.selR = -1;
        this.selC = -1;
        this.startR = -1;
        this.startC = -1;
        this.particles = new ArrayList<>();
        this.popups = new ArrayList<>();
        this.cell = 1.0f;
        this.bgPaint = new Paint();
        Paint $this$textPaint_u24lambda_u240 = new Paint(1);
        $this$textPaint_u24lambda_u240.setTypeface(Typeface.create(Typeface.DEFAULT, 1));
        this.textPaint = $this$textPaint_u24lambda_u240;
        Paint $this$glassFill_u24lambda_u241 = new Paint(1);
        $this$glassFill_u24lambda_u241.setStyle(Paint.Style.FILL);
        this.glassFill = $this$glassFill_u24lambda_u241;
        Paint $this$glassEdge_u24lambda_u242 = new Paint(1);
        $this$glassEdge_u24lambda_u242.setStyle(Paint.Style.STROKE);
        $this$glassEdge_u24lambda_u242.setStrokeWidth(this.dp * 2.2f);
        this.glassEdge = $this$glassEdge_u24lambda_u242;
        Paint $this$shadowRect_u24lambda_u243 = new Paint(1);
        $this$shadowRect_u24lambda_u243.setColor(805306368);
        this.shadowRect = $this$shadowRect_u24lambda_u243;
        Paint $this$cellPaint_u24lambda_u244 = new Paint(1);
        $this$cellPaint_u24lambda_u244.setColor(234881023);
        this.cellPaint = $this$cellPaint_u24lambda_u244;
        this.plain = new Paint(1);
        Paint $this$addPaint_u24lambda_u245 = new Paint(1);
        $this$addPaint_u24lambda_u245.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        this.addPaint = $this$addPaint_u24lambda_u245;
        Paint $this$ringPaint_u24lambda_u246 = new Paint(1);
        $this$ringPaint_u24lambda_u246.setStyle(Paint.Style.STROKE);
        this.ringPaint = $this$ringPaint_u24lambda_u246;
        this.blobColors = new int[]{-53867, -16722689, -8704001, -13804545};
        Paint[] paintArr = new Paint[4];
        for (int i5 = 0; i5 < 4; i5++) {
            Paint $this$blobPaints_u24lambda_u247 = new Paint(1);
            $this$blobPaints_u24lambda_u247.setShader(new RadialGradient(0.0f, 0.0f, 1.0f, withAlpha(this.blobColors[i5], 128), withAlpha(this.blobColors[i5], 0), Shader.TileMode.CLAMP));
            paintArr[i5] = $this$blobPaints_u24lambda_u247;
        }
        this.blobPaints = paintArr;
        float[] fArr = new float[18];
        for (int i6 = 0; i6 < 18; i6++) {
            fArr[i6] = this.rnd.nextFloat();
        }
        this.bokehX = fArr;
        float[] fArr2 = new float[18];
        for (int i7 = 0; i7 < 18; i7++) {
            fArr2[i7] = this.rnd.nextFloat();
        }
        this.bokehY = fArr2;
        float[] fArr3 = new float[18];
        for (int i8 = 0; i8 < 18; i8++) {
            fArr3[i8] = (this.rnd.nextFloat() * 0.03f) + 0.01f;
        }
        this.bokehS = fArr3;
        float[] fArr4 = new float[18];
        for (int i9 = 0; i9 < 18; i9++) {
            fArr4[i9] = (this.rnd.nextFloat() * 0.025f) + 0.01f;
        }
        this.bokehV = fArr4;
        this.shapes = buildShapes();
        int i10 = this.types;
        Paint[] paintArr2 = new Paint[i10];
        for (int i11 = 0; i11 < i10; i11++) {
            Paint $this$fillPaints_u24lambda_u248 = new Paint(1);
            $this$fillPaints_u24lambda_u248.setStyle(Paint.Style.FILL);
            $this$fillPaints_u24lambda_u248.setShader(new RadialGradient(-0.3f, -0.35f, 1.5f, new int[]{this.lightC[i11], this.baseC[i11], this.darkC[i11]}, new float[]{0.0f, 0.55f, 1.0f}, Shader.TileMode.CLAMP));
            $this$fillPaints_u24lambda_u248.setPathEffect(new CornerPathEffect(0.12f));
            paintArr2[i11] = $this$fillPaints_u24lambda_u248;
        }
        this.fillPaints = paintArr2;
        int i12 = this.types;
        Paint[] paintArr3 = new Paint[i12];
        for (int i13 = 0; i13 < i12; i13++) {
            Paint $this$glowPaints_u24lambda_u249 = new Paint(1);
            $this$glowPaints_u24lambda_u249.setShader(new RadialGradient(0.0f, 0.0f, 1.7f, withAlpha(this.baseC[i13], 176), withAlpha(this.baseC[i13], 0), Shader.TileMode.CLAMP));
            paintArr3[i13] = $this$glowPaints_u24lambda_u249;
        }
        this.glowPaints = paintArr3;
        Paint $this$tileShadow_u24lambda_u2410 = new Paint(1);
        $this$tileShadow_u24lambda_u2410.setShader(new RadialGradient(0.0f, 0.0f, 1.1f, 1711276032, 0, Shader.TileMode.CLAMP));
        this.tileShadow = $this$tileShadow_u24lambda_u2410;
        Paint $this$rimPaint_u24lambda_u2411 = new Paint(1);
        $this$rimPaint_u24lambda_u2411.setStyle(Paint.Style.STROKE);
        $this$rimPaint_u24lambda_u2411.setStrokeWidth(0.07f);
        $this$rimPaint_u24lambda_u2411.setColor(-1711276033);
        $this$rimPaint_u24lambda_u2411.setPathEffect(new CornerPathEffect(0.12f));
        this.rimPaint = $this$rimPaint_u24lambda_u2411;
        Paint $this$glossTop_u24lambda_u2412 = new Paint(1);
        $this$glossTop_u24lambda_u2412.setShader(new LinearGradient(0.0f, -0.95f, 0.0f, 0.0f, -1258291201, 16777215, Shader.TileMode.CLAMP));
        this.glossTop = $this$glossTop_u24lambda_u2412;
        Paint $this$glossBottom_u24lambda_u2413 = new Paint(1);
        $this$glossBottom_u24lambda_u2413.setShader(new LinearGradient(0.0f, 0.35f, 0.0f, 1.0f, 16777215, 1442840575, Shader.TileMode.CLAMP));
        this.glossBottom = $this$glossBottom_u24lambda_u2413;
        Paint $this$sparkle_u24lambda_u2414 = new Paint(1);
        $this$sparkle_u24lambda_u2414.setColor(-419430401);
        this.sparkle = $this$sparkle_u24lambda_u2414;
        Path $this$arrowPath_u24lambda_u2415 = new Path();
        $this$arrowPath_u24lambda_u2415.moveTo(0.0f, 0.9f);
        $this$arrowPath_u24lambda_u2415.lineTo(-0.85f, -0.55f);
        $this$arrowPath_u24lambda_u2415.lineTo(0.85f, -0.55f);
        $this$arrowPath_u24lambda_u2415.close();
        this.arrowPath = $this$arrowPath_u24lambda_u2415;
        Paint $this$arrowPaint_u24lambda_u2416 = new Paint(1);
        $this$arrowPaint_u24lambda_u2416.setColor(-10929);
        $this$arrowPaint_u24lambda_u2416.setPathEffect(new CornerPathEffect(0.2f));
        this.arrowPaint = $this$arrowPaint_u24lambda_u2416;
        Paint $this$arrowGlow_u24lambda_u2417 = new Paint(1);
        $this$arrowGlow_u24lambda_u2417.setShader(new RadialGradient(0.0f, 0.0f, 1.6f, -1426078720, 16761856, Shader.TileMode.CLAMP));
        this.arrowGlow = $this$arrowGlow_u24lambda_u2417;
        Settings.load(this.prefs);
        this.sfx.setEnabled(Settings.sound);
        this.sfx.setVolume(Settings.volume);
        applyTheme();
        this.best = Settings.bestFor(Settings.difficulty);
        configureGame();
        newGame();
        Updater.check(this, new Runnable() {
            @Override
            public void run() {
            }
        });
    }

    private final int withAlpha(int c, int a) {
        return (16777215 & c) | (a << 24);
    }

    private static final Path buildShapes$poly(float... p) {
        Path path = new Path();
        path.moveTo(p[0], p[1]);
        for (int i = 2; i < p.length; i += 2) {
            path.lineTo(p[i], p[i + 1]);
        }
        path.close();
        return path;
    }

    private final Path[] buildShapes() {
        double d;
        double d2;
        Path circle = new Path();
        circle.addCircle(0.0f, 0.0f, 0.86f, Path.Direction.CW);
        Path square = new Path();
        square.addRoundRect(new RectF(-0.75f, -0.75f, 0.75f, 0.75f), 0.3f, 0.3f, Path.Direction.CW);
        Path diamond = buildShapes$poly(0.0f, -0.98f, 0.82f, 0.0f, 0.0f, 0.98f, -0.82f, 0.0f);
        Path triangle = buildShapes$poly(0.0f, -0.88f, 0.9f, 0.66f, -0.9f, 0.66f);
        float[] hexPts = new float[12];
        int k = 0;
        while (true) {
            d = 3.141592653589793d;
            d2 = -1.5707963267948966d;
            if (k >= 6) {
                break;
            }
            double a = ((((double) k) * 3.141592653589793d) / ((double) 3)) - 1.5707963267948966d;
            hexPts[k * 2] = (float) (Math.cos(a) * 0.9d);
            hexPts[(k * 2) + 1] = (float) (Math.sin(a) * 0.9d);
            k++;
        }
        int k2 = hexPts.length;
        Path hex = buildShapes$poly(Arrays.copyOf(hexPts, k2));
        float[] starPts = new float[20];
        int k3 = 0;
        while (k3 < 10) {
            Path triangle2 = triangle;
            double a2 = ((((double) k3) * d) / ((double) 5)) + d2;
            double rr = k3 % 2 == 0 ? 0.98d : 0.46d;
            starPts[k3 * 2] = (float) (Math.cos(a2) * rr);
            starPts[(k3 * 2) + 1] = (float) (Math.sin(a2) * rr);
            k3++;
            triangle = triangle2;
            d = 3.141592653589793d;
            d2 = -1.5707963267948966d;
        }
        Path star = buildShapes$poly(Arrays.copyOf(starPts, starPts.length));
        return new Path[]{circle, square, diamond, triangle, hex, star};
    }

    private final float easeInOut(float p) {
        return p < 0.5f ? 4.0f * p * p * p : 1.0f - (((float) Math.pow(((-2.0f) * p) + 2.0f, 3.0f)) / 2.0f);
    }

    private final float easeOutBack(float x) {
        float c3 = 1.70158f + 1.0f;
        return (((float) Math.pow(x - 1.0f, 3.0f)) * c3) + 1.0f + (((float) Math.pow(x - 1.0f, 2.0f)) * 1.70158f);
    }

    private final float easeOutBounce(float x) {
        if (x < 1.0f / 2.75f) {
            return 7.5625f * x * x;
        }
        if (x < 2.0f / 2.75f) {
            float y = x - (1.5f / 2.75f);
            return (7.5625f * y * y) + 0.75f;
        }
        if (x < 2.5f / 2.75f) {
            float y2 = x - (2.25f / 2.75f);
            return (7.5625f * y2 * y2) + 0.9375f;
        }
        float y3 = x - (2.625f / 2.75f);
        return (7.5625f * y3 * y3) + 0.984375f;
    }

    private final int typeAt(int r, int c) {
        Tile tile = this.grid[r][c];
        if (tile != null) {
            return tile.getType();
        }
        return -1;
    }

    private final float cx(float c) {
        return this.bl + ((0.5f + c) * this.cell);
    }

    private final float cy(float r) {
        return this.bt + ((0.5f + r) * this.cell);
    }

    private final void tick() {
        if (Settings.haptics) {
            performHapticFeedback(3);
        }
    }

    private final void newGame() {
        this.score = 0;
        this.displayScore = 0.0f;
        this.moves = this.startMoves;
        this.moveCount = 0;
        this.combo = 1;
        this.lastFlip = 0;
        this.gravityDown = true;
        this.arrowAngle = 0.0f;
        this.flipSy = 1.0f;
        this.selR = -1;
        this.selC = -1;
        this.hint = null;
        this.idleT = 0.0f;
        this.overT = 0.0f;
        this.newBest = false;
        this.levelWon = false;
        this.starsEarned = 0;
        this.starsShown = 0;
        this.bestStart = this.best;
        this.bannerT = 0.0f;
        this.particles.clear();
        this.popups.clear();
        int i = this.n;
        for (int r = 0; r < i; r++) {
            int i2 = this.n;
            for (int c = 0; c < i2; c++) {
                this.grid[r][c] = null;
            }
        }
        dealBoard();
    }

    private final void dealBoard() {
        int tp;
        do {
            int i = this.n;
            for (int r = 0; r < i; r++) {
                int i2 = this.n;
                for (int c = 0; c < i2; c++) {
                    while (true) {
                        tp = this.rnd.nextInt(this.activeTypes);
                        if (c < 2 || typeAt(r, c - 1) != tp || typeAt(r, c - 2) != tp) {
                            if (r < 2 || typeAt(r - 1, c) != tp || typeAt(r - 2, c) != tp) {
                                break;
                            }
                        }
                    }
                    this.grid[r][c] = new Tile(tp, r, c);
                }
            }
        } while (validMoves().isEmpty());
        float maxEnd = 0.0f;
        int i3 = this.n;
        int r2 = 0;
        while (r2 < i3) {
            int i4 = this.n;
            float maxEnd2 = maxEnd;
            for (int c2 = 0; c2 < i4; c2++) {
                Tile tl = this.grid[r2][c2];
                tl.setR(this.gravityDown ? (r2 - this.n) - 1 : this.n + r2 + 1);
                int order = this.gravityDown ? (this.n - 1) - r2 : r2;
                float d = (c2 * 0.025f) + (order * 0.03f);
                startMove(tl, r2, c2, 0.45f, d, true);
                maxEnd2 = Math.max(maxEnd2, d + 0.45f);
            }
            r2++;
            maxEnd = maxEnd2;
        }
        this.phase = 4;
        this.t = 0.0f;
        this.phaseDur = maxEnd;
    }

    private final void startMove(Tile tl, int tr, int tc, float dur, float delay, boolean bounce) {
        tl.setFromR(tl.getR());
        tl.setFromC(tl.getC());
        tl.setToR(tr);
        tl.setToC(tc);
        tl.setDur(dur);
        tl.setDelay(delay);
        tl.setBounce(bounce);
        tl.setMoving(true);
    }

    private final void stepMoves() {
        int i = this.n;
        for (int r = 0; r < i; r++) {
            int i2 = this.n;
            for (int c = 0; c < i2; c++) {
                Tile tl = this.grid[r][c];
                if (tl != null && tl.getMoving()) {
                    float p = RangesKt.coerceIn((this.t - tl.getDelay()) / tl.getDur(), 0.0f, 1.0f);
                    float e = tl.getBounce() ? easeOutBounce(p) : easeInOut(p);
                    tl.setR(tl.getFromR() + ((tl.getToR() - tl.getFromR()) * e));
                    tl.setC(tl.getFromC() + ((tl.getToC() - tl.getFromC()) * e));
                }
            }
        }
    }

    private final void finishMoves() {
        int i = this.n;
        for (int r = 0; r < i; r++) {
            int i2 = this.n;
            for (int c = 0; c < i2; c++) {
                Tile tl = this.grid[r][c];
                if (tl != null && tl.getMoving()) {
                    tl.setR(tl.getToR());
                    tl.setC(tl.getToC());
                    tl.setMoving(false);
                }
            }
        }
    }

    private final void clearMarks() {
        int i = this.n;
        for (int r = 0; r < i; r++) {
            int i2 = this.n;
            for (int c = 0; c < i2; c++) {
                this.marked[r][c] = false;
            }
        }
    }

    private final boolean findMatches() {
        int e;
        int e2;
        clearMarks();
        boolean any = false;
        int i = this.n;
        for (int r = 0; r < i; r++) {
            for (int c = 0; c < this.n; c = e2 + 1) {
                int tp = typeAt(r, c);
                e2 = c;
                while (e2 + 1 < this.n && typeAt(r, e2 + 1) == tp) {
                    e2++;
                }
                if (tp >= 0 && (e2 - c) + 1 >= 3) {
                    int k = c;
                    if (k <= e2) {
                        while (true) {
                            this.marked[r][k] = true;
                            if (k == e2) {
                                break;
                            }
                            k++;
                        }
                    }
                    any = true;
                }
            }
        }
        int i2 = this.n;
        for (int c2 = 0; c2 < i2; c2++) {
            for (int r2 = 0; r2 < this.n; r2 = e + 1) {
                int tp2 = typeAt(r2, c2);
                e = r2;
                while (e + 1 < this.n && typeAt(e + 1, c2) == tp2) {
                    e++;
                }
                if (tp2 >= 0 && (e - r2) + 1 >= 3) {
                    int k2 = r2;
                    if (k2 <= e) {
                        while (true) {
                            this.marked[k2][c2] = true;
                            if (k2 == e) {
                                break;
                            }
                            k2++;
                        }
                    }
                    any = true;
                }
            }
        }
        return any;
    }

    private final void swapRef(int r1, int c1, int r2, int c2) {
        Tile x = this.grid[r1][c1];
        this.grid[r1][c1] = this.grid[r2][c2];
        this.grid[r2][c2] = x;
    }

    private final ArrayList<int[]> validMoves() {
        ArrayList<int[]> arrayList = new ArrayList<>();
        int i = this.n;
        for (int r = 0; r < i; r++) {
            int i2 = this.n;
            for (int c = 0; c < i2; c++) {
                if (c + 1 < this.n) {
                    swapRef(r, c, r, c + 1);
                    if (findMatches()) {
                        arrayList.add(new int[]{r, c, r, c + 1});
                    }
                    swapRef(r, c, r, c + 1);
                }
                if (r + 1 < this.n) {
                    swapRef(r, c, r + 1, c);
                    if (findMatches()) {
                        arrayList.add(new int[]{r, c, r + 1, c});
                    }
                    swapRef(r, c, r + 1, c);
                }
            }
        }
        clearMarks();
        return arrayList;
    }

    private final void startSwap(int r1, int c1, int r2, int c2) {
        if (this.phase != 0 || this.moves <= 0 || this.grid[r1][c1] == null || this.grid[r2][c2] == null) {
            return;
        }
        this.sR1 = r1;
        this.sC1 = c1;
        this.sR2 = r2;
        this.sC2 = c2;
        Tile tile = this.grid[r1][c1];
        startMove(tile, r2, c2, 0.17f, 0.0f, false);
        Tile tile2 = this.grid[r2][c2];
        startMove(tile2, r1, c1, 0.17f, 0.0f, false);
        this.phase = 1;
        this.t = 0.0f;
        this.phaseDur = 0.17f;
        this.hint = null;
        this.idleT = 0.0f;
        this.sfx.swap();
    }

    private final void startClear() {
        this.phase = 3;
        this.t = 0.0f;
        this.phaseDur = 0.34f;
        int cnt = 0;
        float sumC = 0.0f;
        float sumR = 0.0f;
        int i = this.n;
        for (int r = 0; r < i; r++) {
            int i2 = this.n;
            for (int c = 0; c < i2; c++) {
                if (this.marked[r][c]) {
                    Tile tl = this.grid[r][c];
                    cnt++;
                    sumC += c;
                    sumR += r;
                    burst(cx(c), cy(r), tl.getType());
                }
            }
        }
        int r2 = cnt * 10;
        int pts = r2 * this.combo;
        this.score += pts;
        if (this.mode == 0 && this.score > this.best) {
            this.best = this.score;
            Settings.setBest(Settings.difficulty, this.best);
        }
        this.scorePop = 1.0f;
        if (this.combo > Settings.bestCombo) {
            Settings.bestCombo = this.combo;
        }
        if (this.mode == 0 && this.score > Settings.maxEndless) {
            Settings.maxEndless = this.score;
        }
        float px = cx(sumC / cnt);
        float py = cy(sumR / cnt);
        this.popups.add(new Popup("+" + pts, px, py, 1.0f, -1));
        if (this.combo > 1) {
            this.popups.add(new Popup("COMBO x" + this.combo, px, py - (this.cell * 0.7f), 1.0f, -10929));
        }
        this.sfx.match(this.combo);
        tick();
        this.shake = Math.max(this.shake, Math.min(0.7f, (this.combo * 0.12f) + (cnt * 0.03f)));
    }

    private final void startFall() {
        float maxEnd;
        this.phase = 4;
        this.t = 0.0f;
        float maxEnd2 = 0.1f;
        int i = this.n;
        for (int c = 0; c < i; c++) {
            Tile tile = null;
            if (!this.gravityDown) {
                int i2 = this.n;
                float maxEnd3 = maxEnd2;
                int w = 0;
                for (int r = 0; r < i2; r++) {
                    Tile tl = this.grid[r][c];
                    if (tl != null) {
                        if (w != r) {
                            this.grid[w][c] = tl;
                            this.grid[r][c] = null;
                            float du = startFall$dur(r - w);
                            startMove(tl, w, c, du, 0.0f, true);
                            maxEnd3 = Math.max(maxEnd3, du);
                        }
                        w++;
                    }
                }
                int r2 = w;
                int i3 = this.n;
                int k = 0;
                maxEnd = maxEnd3;
                for (int r3 = r2; r3 < i3; r3++) {
                    Tile tl2 = new Tile(this.rnd.nextInt(this.activeTypes), this.n + k, c);
                    this.grid[r3][c] = tl2;
                    float du2 = startFall$dur(tl2.getR() - r3);
                    float d = k * 0.05f;
                    startMove(tl2, r3, c, du2, d, true);
                    maxEnd = Math.max(maxEnd, d + du2);
                    k++;
                }
            } else {
                int w2 = this.n - 1;
                float maxEnd4 = maxEnd2;
                int w3 = w2;
                int r4 = this.n - 1;
                while (-1 < r4) {
                    Tile tl3 = this.grid[r4][c];
                    if (tl3 != null) {
                        if (w3 != r4) {
                            this.grid[w3][c] = tl3;
                            this.grid[r4][c] = tile;
                            float du3 = startFall$dur(w3 - r4);
                            startMove(tl3, w3, c, du3, 0.0f, true);
                            maxEnd4 = Math.max(maxEnd4, du3);
                        }
                        w3--;
                    }
                    r4--;
                    tile = null;
                }
                int k2 = 0;
                maxEnd = maxEnd4;
                for (int r5 = w3; -1 < r5; r5--) {
                    Tile tl4 = new Tile(this.rnd.nextInt(this.activeTypes), (-1) - k2, c);
                    this.grid[r5][c] = tl4;
                    float du4 = startFall$dur(r5 - tl4.getR());
                    float d2 = k2 * 0.05f;
                    startMove(tl4, r5, c, du4, d2, true);
                    maxEnd = Math.max(maxEnd, d2 + du4);
                    k2++;
                }
            }
            maxEnd2 = maxEnd;
        }
        this.phaseDur = maxEnd2;
    }

    private static final float startFall$dur(float d) {
        return (((float) Math.sqrt(d)) * 0.07f) + 0.17f;
    }

    private final void afterResolve() {
        if (this.mode == 1 && this.score >= this.levelTarget) {
            finishTurn();
            return;
        }
        if (this.flipEvery > 0 && this.moves > 0 && this.moveCount > 0 && this.moveCount % this.flipEvery == 0 && this.lastFlip != this.moveCount) {
            this.lastFlip = this.moveCount;
            this.phase = 5;
            this.t = 0.0f;
            this.phaseDur = 0.95f;
            this.flipMid = false;
            this.bannerText = "GRAVITY FLIP!";
            this.bannerT = 1.5f;
            this.sfx.flip();
            return;
        }
        finishTurn();
    }

    private final void finishTurn() {
        boolean z = false;
        checkAchievements();
        if (this.mode == 1) {
            if (this.score >= this.levelTarget) {
                winLevel();
                return;
            }
            if (this.moves <= 0) {
                failLevel();
                return;
            }
        }
        if (this.mode == 0 && this.moves <= 0) {
            Settings.save();
            this.phase = 7;
            this.overT = 0.0f;
            if (this.score > this.bestStart && this.score > 0) {
                z = true;
            }
            this.newBest = z;
            this.sfx.over();
            if (this.newBest) {
                confetti();
                return;
            }
            return;
        }
        if (validMoves().isEmpty()) {
            this.phase = 6;
            this.t = 0.0f;
            this.phaseDur = 0.3f;
            this.bannerText = "NO MOVES - SHUFFLE";
            this.bannerT = 1.4f;
            return;
        }
        this.phase = 0;
        this.idleT = 0.0f;
        this.hint = null;
    }

    private final void burst(float x, float y, int type) {
        if (this.particles.size() > 500) {
            return;
        }
        if (Settings.particles <= 0.01f) {
            return;
        }
        int bn = Math.max(1, Math.round(9 * Settings.particles));
        for (int i = 0; i < bn; i++) {
            float a = this.rnd.nextFloat() * 6.2831855f;
            float sp = this.cell * ((this.rnd.nextFloat() * 5.0f) + 2.5f);
            float life = (this.rnd.nextFloat() * 0.45f) + 0.45f;
            int col = this.rnd.nextInt(3) == 0 ? -1 : this.lightC[type];
            this.particles.add(new Particle(x, y, ((float) Math.cos(a)) * sp, (((float) Math.sin(a)) * sp) - (this.cell * 2.0f), life, life, this.cell * ((this.rnd.nextFloat() * 0.08f) + 0.05f), col, 0));
        }
        this.particles.add(new Particle(x, y, 0.0f, 0.0f, 0.45f, 0.45f, this.cell * 0.9f, this.baseC[type], 1));
    }

    private final void confetti() {
        float w = getWidth();
        int cn = (int) (70 * Math.max(0.3f, Settings.particles));
        for (int i = 0; i < cn; i++) {
            float life = (this.rnd.nextFloat() * 1.2f) + 1.2f;
            this.particles.add(new Particle(this.rnd.nextFloat() * w, -20.0f, (this.rnd.nextFloat() - 0.5f) * this.cell * 3.0f, this.cell * ((this.rnd.nextFloat() * 4.0f) + 2.0f), life, life, this.cell * ((this.rnd.nextFloat() * 0.08f) + 0.06f), this.lightC[this.rnd.nextInt(this.activeTypes)], 0));
        }
    }

    private final void update(float dt) {
        Tile tl;
        this.time += dt;
        this.displayScore += (this.score - this.displayScore) * Math.min(1.0f, 8.0f * dt);
        if (Math.abs(this.score - this.displayScore) < 0.6f) {
            this.displayScore = this.score;
        }
        this.shake = Math.max(0.0f, this.shake - (dt * 3.0f));
        this.flash = Math.max(0.0f, this.flash - (2.5f * dt));
        this.scorePop = Math.max(0.0f, this.scorePop - (3.0f * dt));
        if (this.bannerT > 0.0f) {
            this.bannerT -= dt;
        }
        float target = this.gravityDown ? 0.0f : 180.0f;
        this.arrowAngle += (target - this.arrowAngle) * Math.min(1.0f, 7.0f * dt);
        int size = this.particles.size() - 1;
        if (size >= 0) {
            do {
                int i = size;
                size--;
                Particle particle = this.particles.get(i);
                Particle p = particle;
                p.setLife(p.getLife() - dt);
                if (p.getLife() <= 0.0f) {
                    this.particles.remove(i);
                } else if (p.getKind() == 0) {
                    p.setX(p.getX() + (p.getVx() * dt));
                    p.setY(p.getY() + (p.getVy() * dt));
                    p.setVy(p.getVy() + (this.cell * 10.0f * dt));
                    p.setVx(p.getVx() * 0.99f);
                }
            } while (size >= 0);
        }
        int size2 = this.popups.size() - 1;
        if (size2 >= 0) {
            do {
                int i2 = size2;
                size2--;
                Popup popup = this.popups.get(i2);
                popup.setLife(popup.getLife() - (0.9f * dt));
                if (this.popups.get(i2).getLife() <= 0.0f) {
                    this.popups.remove(i2);
                }
            } while (size2 >= 0);
        }
        switch (this.phase) {
            case 0:
                this.idleT += dt;
                if (this.hintDelay > 0.0f && this.idleT > this.hintDelay && this.hint == null) {
                    ArrayList<int[]> arrayListValidMoves = validMoves();
                    if (!arrayListValidMoves.isEmpty()) {
                        this.hint = arrayListValidMoves.get(this.rnd.nextInt(arrayListValidMoves.size()));
                    }
                    break;
                }
                break;
            case 1:
                this.t += dt;
                stepMoves();
                if (this.t >= this.phaseDur) {
                    finishMoves();
                    swapRef(this.sR1, this.sC1, this.sR2, this.sC2);
                    if (findMatches()) {
                        this.moves--;
                        this.moveCount++;
                        this.combo = 1;
                        startClear();
                    } else {
                        swapRef(this.sR1, this.sC1, this.sR2, this.sC2);
                        this.sfx.bad();
                        Tile tile = this.grid[this.sR1][this.sC1];
                        startMove(tile, this.sR1, this.sC1, 0.17f, 0.0f, false);
                        Tile tile2 = this.grid[this.sR2][this.sC2];
                        startMove(tile2, this.sR2, this.sC2, 0.17f, 0.0f, false);
                        this.phase = 2;
                        this.t = 0.0f;
                        this.phaseDur = 0.17f;
                    }
                }
                break;
            case 2:
                this.t += dt;
                stepMoves();
                if (this.t >= this.phaseDur) {
                    finishMoves();
                    this.phase = 0;
                    this.idleT = 0.0f;
                }
                break;
            case 3:
                this.t += dt;
                float p2 = Math.min(1.0f, this.t / this.phaseDur);
                int i3 = this.n;
                for (int r = 0; r < i3; r++) {
                    int i4 = this.n;
                    for (int c = 0; c < i4; c++) {
                        if (this.marked[r][c] && (tl = this.grid[r][c]) != null) {
                            if (p2 < 0.25f) {
                                tl.setScale(((p2 / 0.25f) * 0.3f) + 1.0f);
                            } else {
                                float q = (p2 - 0.25f) / 0.75f;
                                tl.setScale(((float) Math.pow(1.0f - q, 1.5f)) * 1.3f);
                                tl.setAlpha(1.0f - q);
                            }
                        }
                    }
                }
                if (this.t >= this.phaseDur) {
                    int i5 = this.n;
                    for (int r2 = 0; r2 < i5; r2++) {
                        int i6 = this.n;
                        for (int c2 = 0; c2 < i6; c2++) {
                            if (this.marked[r2][c2]) {
                                this.grid[r2][c2] = null;
                            }
                        }
                    }
                    clearMarks();
                    startFall();
                }
                break;
            case 4:
                this.t += dt;
                stepMoves();
                if (this.t >= this.phaseDur) {
                    finishMoves();
                    this.sfx.land();
                    if (findMatches()) {
                        this.combo++;
                        startClear();
                    } else {
                        afterResolve();
                    }
                }
                break;
            case FLIP /* 5 */:
                this.t += dt;
                float p3 = Math.min(1.0f, this.t / this.phaseDur);
                this.flipSy = (float) Math.cos(3.1415927f * p3);
                if (p3 > 0.5f && !this.flipMid) {
                    this.flipMid = true;
                    this.gravityDown = !this.gravityDown;
                    Settings.cntFlips++;
                    this.flash = 1.0f;
                    this.shake = 0.5f;
                    tick();
                }
                if (this.t >= this.phaseDur) {
                    int i7 = this.n / 2;
                    for (int r3 = 0; r3 < i7; r3++) {
                        int i8 = this.n;
                        for (int c3 = 0; c3 < i8; c3++) {
                            swapRef(r3, c3, (this.n - 1) - r3, c3);
                        }
                    }
                    int i9 = this.n;
                    for (int r4 = 0; r4 < i9; r4++) {
                        int i10 = this.n;
                        for (int c4 = 0; c4 < i10; c4++) {
                            Tile tile3 = this.grid[r4][c4];
                            if (tile3 != null) {
                                tile3.setR(r4);
                            }
                        }
                    }
                    this.flipSy = 1.0f;
                    finishTurn();
                }
                break;
            case SHUFFLE /* 6 */:
                this.t += dt;
                float p4 = Math.min(1.0f, this.t / this.phaseDur);
                int i11 = this.n;
                for (int r5 = 0; r5 < i11; r5++) {
                    int i12 = this.n;
                    for (int c5 = 0; c5 < i12; c5++) {
                        Tile it = this.grid[r5][c5];
                        if (it != null) {
                            it.setScale(1.0f - p4);
                            it.setAlpha(1.0f - p4);
                        }
                    }
                }
                if (this.t >= this.phaseDur) {
                    dealBoard();
                }
                break;
            case OVER /* 7 */:
                this.overT += dt;
                break;
        }
    }

    private final Glass makeGlass(float l, float tp, float r, float b, float rad) {
        LinearGradient fill = new LinearGradient(0.0f, tp, 0.0f, b, new int[]{1258291199, 486539263, 285212671}, new float[]{0.0f, 0.5f, 1.0f}, Shader.TileMode.CLAMP);
        LinearGradient edge = new LinearGradient(l, tp, r, b, new int[]{-1056964609, 687865855, 1493172223}, new float[]{0.0f, 0.55f, 1.0f}, Shader.TileMode.CLAMP);
        return new Glass(new RectF(l, tp, r, b), rad, fill, edge);
    }

    @Override // android.view.View
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float W = w;
        float H = h;
        float margin = W * 0.04f;
        float gap = W * 0.03f;
        this.titleY = H * 0.072f;
        float cardTop = H * 0.092f;
        float cardH = Math.min(0.072f * H, 0.17f * W);
        float f = 2;
        float cw = ((W - (f * margin)) - gap) / 2.0f;
        float rad = cardH * 0.28f;
        float row2 = cardTop + cardH + (0.8f * gap);
        this.cardScore = makeGlass(margin, cardTop, margin + cw, cardTop + cardH, rad);
        this.cardBest = makeGlass(margin + cw + gap, cardTop, W - margin, cardTop + cardH, rad);
        this.cardMoves = makeGlass(margin, row2, margin + cw, row2 + cardH, rad);
        this.cardGravity = makeGlass(margin + cw + gap, row2, W - margin, row2 + cardH, rad);
        float hudBottom = row2 + cardH;
        float pad = W * 0.022f;
        float bottomLimit = H * 0.9f;
        this.cell = Math.min(((W - (f * margin)) - (f * pad)) / this.n, (((bottomLimit - hudBottom) - gap) - (f * pad)) / this.n);
        this.boardW = this.cell * this.n;
        this.bl = (W - this.boardW) / 2.0f;
        float availTop = hudBottom + gap;
        this.bt = availTop + Math.max(0.0f, (((bottomLimit - availTop) - this.boardW) - (f * pad)) / 2.0f) + pad;
        this.boardGlass = makeGlass(this.bl - pad, this.bt - pad, this.bl + this.boardW + pad, this.bt + this.boardW + pad, 0.35f * this.cell);
        float sw = W * 0.36f;
        float sh = H * 0.05f;
        float bw = W * 0.29f;
        float bh = H * 0.05f;
        float by = H * 0.925f;
        this.menuGlass = makeGlass(margin, by, margin + bw, by + bh, bh / f);
        this.soundGlass = makeGlass((W / f) - (bw / f), by, (W / f) + (bw / f), by + bh, bh / f);
        this.restartGlass = makeGlass(W - margin - bw, by, W - margin, by + bh, bh / f);
        this.overGlass = makeGlass(W * 0.08f, H * 0.25f, W * 0.92f, H * 0.69f, W * 0.07f);
        this.bgShader = new LinearGradient(0.0f, 0.0f, 0.0f, H, this.themeBg, new float[]{0.0f, 0.55f, 1.0f}, Shader.TileMode.CLAMP);
        this.titleShader = new LinearGradient(W * 0.25f, 0.0f, W * 0.75f, 0.0f, -11670529, -41814, Shader.TileMode.CLAMP);
    }

    private final int cellRow(float y) {
        if (y < this.bt) {
            return -1;
        }
        return (int) ((y - this.bt) / this.cell);
    }

    private final int cellCol(float x) {
        if (x < this.bl) {
            return -1;
        }
        return (int) ((x - this.bl) / this.cell);
    }

    private boolean gameTouch(MotionEvent e) {
        boolean z = false;
        switch (e.getAction()) {
            case 0:
                this.startR = -1;
                this.startC = -1;
                this.handled = false;
                if (this.phase == 7) {
                    return true;
                }
                if (this.phase != 0) {
                    return true;
                }
                this.hint = null;
                this.idleT = 0.0f;
                int r = cellRow(e.getY());
                int c = cellCol(e.getX());
                if (r >= 0 && r < this.n) {
                    if (c >= 0 && c < this.n) {
                        z = true;
                    }
                    if (z) {
                        this.startR = r;
                        this.startC = c;
                    }
                }
                this.startX = e.getX();
                this.startY = e.getY();
                return true;
            case 1:
                if (!this.handled && this.startR >= 0 && this.phase == 0) {
                    if (this.selR < 0) {
                        this.selR = this.startR;
                        this.selC = this.startC;
                        this.sfx.tap();
                    } else if (this.selR == this.startR && this.selC == this.startC) {
                        this.selR = -1;
                        this.selC = -1;
                    } else if (Math.abs(this.selR - this.startR) + Math.abs(this.selC - this.startC) == 1) {
                        int a = this.selR;
                        int b = this.selC;
                        this.selR = -1;
                        this.selC = -1;
                        startSwap(a, b, this.startR, this.startC);
                    } else {
                        this.selR = this.startR;
                        this.selC = this.startC;
                        this.sfx.tap();
                    }
                }
                return true;
            case 2:
                if (!this.handled && this.startR >= 0 && this.phase == 0) {
                    float dx = e.getX() - this.startX;
                    float dy = e.getY() - this.startY;
                    if (Math.abs(dx) > this.cell * 0.35f || Math.abs(dy) > this.cell * 0.35f) {
                        int r2 = this.startR;
                        int c2 = this.startC;
                        if (Math.abs(dx) > Math.abs(dy)) {
                            c2 += dx > 0.0f ? 1 : -1;
                        } else {
                            r2 += dy > 0.0f ? 1 : -1;
                        }
                        this.handled = true;
                        this.selR = -1;
                        this.selC = -1;
                        if (r2 >= 0 && r2 < this.n) {
                            if (c2 >= 0 && c2 < this.n) {
                                z = true;
                            }
                            if (z) {
                                startSwap(this.startR, this.startC, r2, c2);
                            }
                        }
                    }
                }
                return true;
            default:
                return true;
        }
    }

    private final void drawBackground(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        this.bgPaint.setShader(this.bgShader);
        canvas.drawRect(0.0f, 0.0f, w, h, this.bgPaint);
        if (!Settings.bgFx) {
            return;
        }
        for (int i = 0; i < 4; i++) {
            float x = ((((float) Math.sin((this.time * 0.13f * (i + 1)) + (i * 1.7f))) * 0.42f) + 0.5f) * w;
            float y = ((((float) Math.cos((this.time * 0.11f * (i + 2)) + (i * 2.3f))) * 0.42f) + 0.5f) * h;
            float rad = ((((float) Math.sin((this.time * 0.2f) + i)) * 0.2f) + 0.75f) * w;
            canvas.save();
            canvas.translate(x, y);
            canvas.scale(rad, rad);
            canvas.drawCircle(0.0f, 0.0f, 1.0f, this.blobPaints[i]);
            canvas.restore();
        }
        int length = this.bokehX.length;
        for (int i2 = 0; i2 < length; i2++) {
            float y2 = (((this.bokehY[i2] - (this.time * this.bokehV[i2])) % 1.0f) + 1.0f) % 1.0f;
            float x2 = this.bokehX[i2] + (((float) Math.sin((this.time * 0.5f) + i2)) * 0.03f);
            this.plain.setShader(null);
            this.plain.setColor(352321535);
            canvas.drawCircle(x2 * w, y2 * h, this.bokehS[i2] * w, this.plain);
            this.plain.setColor(285212671);
            canvas.drawCircle((x2 * w) - ((this.bokehS[i2] * w) * 0.25f), (y2 * h) - ((this.bokehS[i2] * w) * 0.25f), this.bokehS[i2] * w * 0.35f, this.plain);
        }
    }

    private final void drawGlass(Canvas canvas, Glass g) {
        float sh = this.dp * 5.0f;
        canvas.drawRoundRect(g.getRect().left, g.getRect().top + sh, g.getRect().right, g.getRect().bottom + sh, g.getRadius(), g.getRadius(), this.shadowRect);
        this.glassFill.setShader(g.getFill());
        canvas.drawRoundRect(g.getRect(), g.getRadius(), g.getRadius(), this.glassFill);
        this.glassEdge.setShader(g.getEdge());
        canvas.drawRoundRect(g.getRect(), g.getRadius(), g.getRadius(), this.glassEdge);
    }

    static /* synthetic */ void drawText$default(GameView gameView, Canvas canvas, String str, float f, float f2, float f3, int i, Paint.Align align, int i2, Object obj) {
        Paint.Align align2;
        if ((i2 & 64) == 0) {
            align2 = align;
        } else {
            align2 = Paint.Align.CENTER;
        }
        gameView.drawText(canvas, str, f, f2, f3, i, align2);
    }

    private final void drawText(Canvas canvas, String s, float x, float y, float size, int color, Paint.Align align) {
        this.textPaint.setShader(null);
        this.textPaint.setTextSize(size);
        this.textPaint.setColor(color);
        this.textPaint.setTextAlign(align);
        canvas.drawText(s, x, y, this.textPaint);
    }

    private final void drawCard(Canvas canvas, Glass g, String label, String value, int valueColor, float pop) {
        drawGlass(canvas, g);
        float h = g.getRect().height();
        float cxm = g.getRect().centerX();
        drawText$default(this, canvas, label, cxm, g.getRect().top + (0.34f * h), h * 0.17f, -1426063361, null, 64, null);
        drawText$default(this, canvas, value, cxm, g.getRect().top + (0.8f * h), 0.4f * h * ((0.18f * pop) + 1.0f), valueColor, null, 64, null);
    }

    private final void drawHud(Canvas canvas) {
        Shader shader;
        float w = getWidth();
        this.textPaint.setTextSize(w * 0.07f);
        this.textPaint.setLetterSpacing(0.14f);
        this.textPaint.setTextAlign(Paint.Align.CENTER);
        this.textPaint.setShader(this.titleShader);
        this.textPaint.setColor(-1);
        canvas.drawText("FLIP MATCH", w / 2.0f, this.titleY, this.textPaint);
        this.textPaint.setShader(null);
        this.textPaint.setLetterSpacing(0.04f);
        Glass it = this.cardScore;
        if (it != null) {
            drawCard(canvas, it, "SCORE", String.valueOf((int) this.displayScore), -1, this.scorePop);
        }
        Glass it2 = this.cardBest;
        if (it2 != null) {
            if (this.mode == 1) {
                drawTargetCard(canvas, it2);
            } else {
                drawCard(canvas, it2, "BEST", String.valueOf(this.best), -10929, 0.0f);
            }
        }
        Glass it3 = this.cardMoves;
        if (it3 != null) {
            int col = this.moves <= 5 ? -38037 : -1;
            drawCard(canvas, it3, "MOVES", String.valueOf(this.moves), col, 0.0f);
        }
        Glass g = this.cardGravity;
        if (g != null) {
            drawGlass(canvas, g);
            float h = g.getRect().height();
            Shader shader2 = null;
            drawText$default(this, canvas, "GRAVITY", g.getRect().centerX(), g.getRect().top + (0.34f * h), h * 0.17f, -1426063361, null, 64, null);
            float ay = g.getRect().top + (0.67f * h);
            float ax = g.getRect().left + (g.getRect().width() * 0.2f);
            float asz = 0.19f * h;
            canvas.save();
            canvas.translate(ax, ay);
            canvas.scale(asz, asz);
            canvas.rotate(this.arrowAngle);
            float f = 1.6f;
            canvas.drawCircle(0.0f, 0.0f, 1.6f, this.arrowGlow);
            canvas.drawPath(this.arrowPath, this.arrowPaint);
            canvas.restore();
            if (this.flipEvery == 0) {
                drawText$default(this, canvas, "OFF", g.getRect().left + (g.getRect().width() * 0.7f), ay + (0.1f * h), 0.3f * h, -1426063361, null, 64, null);
            }
            int fe = Math.max(1, this.flipEvery);
            int filled = (this.moveCount <= 0 || this.moveCount % fe != 0 || this.lastFlip == this.moveCount) ? this.moveCount % fe : fe;
            float dotR = 0.07f * h;
            float x0 = g.getRect().left + (g.getRect().width() * 0.42f);
            float step = g.getRect().width() * 0.105f;
            int i = 0;
            int i2 = this.flipEvery > 0 ? this.flipEvery : 0;
            while (i < i2) {
                float dx = (i * step) + x0;
                if (i < filled) {
                    canvas.save();
                    canvas.translate(dx, ay);
                    canvas.scale(dotR * 2.2f, dotR * 2.2f);
                    canvas.drawCircle(0.0f, 0.0f, f, this.arrowGlow);
                    canvas.restore();
                    shader = null;
                    this.plain.setShader(null);
                    this.plain.setColor(-10929);
                } else {
                    shader = shader2;
                    this.plain.setShader(shader);
                    this.plain.setColor(956301311);
                }
                canvas.drawCircle(dx, ay, dotR, this.plain);
                i++;
                shader2 = shader;
                f = 1.6f;
            }
        }
        Glass it4 = this.soundGlass;
        if (it4 != null) {
            drawGlass(canvas, it4);
            String label = this.sfx.getEnabled() ? "SOUND  ON" : "SOUND  OFF";
            drawText$default(this, canvas, label, it4.getRect().centerX(), it4.getRect().centerY() + (it4.getRect().height() * 0.17f), it4.getRect().height() * 0.38f, this.sfx.getEnabled() ? -1 : -1996488705, null, 64, null);
        }
        drawGameButtons(canvas);
        drawText$default(this, canvas, footerText(), w / 2.0f, getHeight() * 0.985f, w * 0.032f, -1996488705, null, 64, null);
    }

    private final void drawBoard(Canvas canvas) {
        float s;
        float rot;
        Glass it = this.boardGlass;
        if (it != null) {
            drawGlass(canvas, it);
        }
        float inset = this.cell * 0.06f;
        float rr = this.cell * 0.2f;
        int i = this.n;
        for (int r = 0; r < i; r++) {
            int i2 = this.n;
            for (int c = 0; c < i2; c++) {
                if ((r + c) % 2 == 0) {
                    float l = this.bl + (c * this.cell) + inset;
                    float tp = this.bt + (r * this.cell) + inset;
                    float f = 2;
                    canvas.drawRoundRect(l, tp, (l + this.cell) - (f * inset), (tp + this.cell) - (f * inset), rr, rr, this.cellPaint);
                }
            }
        }
        canvas.save();
        canvas.clipRect(this.bl - (this.cell * 0.02f), this.bt - (this.cell * 0.02f), this.bl + this.boardW + (this.cell * 0.02f), this.bt + this.boardW + (this.cell * 0.02f));
        float midY = this.bt + (this.boardW / 2.0f);
        float sy = this.flipSy;
        float squash = Math.max(0.04f, Math.abs(sy));
        float rad = this.cell * 0.46f;
        int[] hnt = this.hint;
        int i3 = this.n;
        int r2 = 0;
        while (r2 < i3) {
            int i4 = this.n;
            int c2 = 0;
            while (c2 < i4) {
                Tile tl = this.grid[r2][c2];
                if (tl != null && tl.getAlpha() > 0.01f) {
                    float px = cx(tl.getC());
                    float py0 = cy(tl.getR());
                    float py = midY + ((py0 - midY) * sy);
                    float s2 = tl.getScale();
                    float glow = 0.0f;
                    if (this.selR == r2 && this.selC == c2 && this.phase == 0) {
                        s2 *= (((float) Math.sin(this.time * 9.0f)) * 0.05f) + 1.1f;
                        glow = 0.9f;
                    }
                    if (hnt != null && this.phase == 0 && ((hnt[0] == r2 && hnt[1] == c2) || (hnt[2] == r2 && hnt[3] == c2))) {
                        float s3 = s2 * ((((float) Math.sin(this.time * 10.0f)) * 0.08f) + 1.0f);
                        float rot2 = ((float) Math.sin(this.time * 12.0f)) * 7.0f;
                        glow = 0.6f;
                        s = s3;
                        rot = rot2;
                    } else {
                        s = s2;
                        rot = 0.0f;
                    }
                    drawTile(canvas, tl.getType(), px, py, rad, s, s * squash, (this.marked[r2][c2] && this.phase == 3) ? 1.0f : glow, tl.getAlpha(), rot);
                }
                c2++;
                i3 = i3;
                sy = sy;
                i4 = i4;
                r2 = r2;
                hnt = hnt;
            }
            r2++;
        }
        canvas.restore();
    }

    private final void drawTile(Canvas canvas, int type, float x, float y, float rad, float sx, float sy, float glow, float alpha, float rot) {
        canvas.save();
        canvas.translate(x, y);
        canvas.scale(rad * sx, rad * sy);
        if (!(rot == 0.0f)) {
            canvas.rotate(rot);
        }
        int a255 = RangesKt.coerceIn((int) (255.0f * alpha), 0, 255);
        if (glow > 0.0f) {
            this.glowPaints[type].setAlpha(RangesKt.coerceIn((int) (a255 * glow), 0, 255));
            canvas.drawCircle(0.0f, 0.0f, 1.7f, this.glowPaints[type]);
        }
        this.tileShadow.setAlpha((int) (a255 * 0.9f));
        canvas.drawCircle(0.0f, 0.2f, 1.1f, this.tileShadow);
        Path path = this.shapes[type];
        Paint fp = this.fillPaints[type];
        fp.setAlpha(a255);
        canvas.drawPath(path, fp);
        canvas.save();
        canvas.clipPath(path);
        this.glossTop.setAlpha(a255);
        canvas.drawRect(-1.1f, -1.1f, 1.1f, 0.05f, this.glossTop);
        this.glossBottom.setAlpha(a255);
        canvas.drawRect(-1.1f, 0.3f, 1.1f, 1.1f, this.glossBottom);
        canvas.restore();
        this.sparkle.setAlpha((int) (a255 * 0.9f));
        canvas.drawCircle(-0.36f, -0.42f, 0.1f, this.sparkle);
        canvas.drawCircle(-0.14f, -0.6f, 0.045f, this.sparkle);
        this.rimPaint.setAlpha((int) (a255 * 0.6f));
        canvas.drawPath(path, this.rimPaint);
        fp.setAlpha(255);
        canvas.restore();
    }

    private final void drawParticles(Canvas canvas) {
        for (Particle p : this.particles) {
            float k = p.getLife() / p.getMaxLife();
            if (p.getKind() == 0) {
                int a = RangesKt.coerceIn((int) (255 * k), 0, 255);
                this.addPaint.setColor(withAlpha(p.getColor(), (int) (a * 0.35f)));
                canvas.drawCircle(p.getX(), p.getY(), p.getSize() * 2.4f * k, this.addPaint);
                this.addPaint.setColor(withAlpha(p.getColor(), a));
                canvas.drawCircle(p.getX(), p.getY(), p.getSize() * ((0.8f * k) + 0.4f), this.addPaint);
            } else {
                float prog = 1.0f - k;
                this.ringPaint.setStrokeWidth(this.cell * 0.07f * k);
                this.ringPaint.setColor(withAlpha(p.getColor(), (int) (200 * k)));
                canvas.drawCircle(p.getX(), p.getY(), p.getSize() * ((0.9f * prog) + 0.3f), this.ringPaint);
            }
        }
        for (Popup pp : this.popups) {
            float k2 = pp.getLife();
            float grow = easeOutBack(Math.min(1.0f, (1.0f - k2) * 6.0f));
            float yy = pp.getY() - (((1.0f - k2) * this.cell) * 1.1f);
            int a2 = RangesKt.coerceIn((int) (Math.min(1.0f, 2.5f * k2) * 255), 0, 255);
            this.textPaint.setShadowLayer(this.cell * 0.12f, 0.0f, 0.0f, withAlpha(-16777216, a2));
            drawText$default(this, canvas, pp.getText(), pp.getX(), yy, this.cell * 0.5f * ((0.6f * grow) + 0.4f), withAlpha(pp.getColor(), a2), null, 64, null);
            this.textPaint.clearShadowLayer();
        }
    }

    private final void drawBanner(Canvas canvas) {
        if (this.bannerT <= 0.0f) {
            return;
        }
        float w = getWidth();
        float age = 1.5f - this.bannerT;
        float s = easeOutBack(Math.min(1.0f, age / 0.3f));
        int a = RangesKt.coerceIn((int) (Math.min(1.0f, this.bannerT / 0.35f) * 255), 0, 255);
        this.textPaint.setShadowLayer(0.03f * w, 0.0f, 0.0f, withAlpha(-19712, a));
        drawText$default(this, canvas, this.bannerText, w / 2.0f, this.bt + (this.boardW / 2.0f), ((0.7f * s) + 0.3f) * 0.095f * w, withAlpha(-8062, a), null, 64, null);
        this.textPaint.clearShadowLayer();
    }

    // =====================================================================
    //  v3.0 additions: home, levels, settings, liquid-glass UI
    //  Developed & created by Ayush Vaitage
    // =====================================================================

    private static int clampInt(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    boolean handleBack() {
        if (this.popupKind != 0) {
            popupClose();
            return true;
        }
        switch (this.screen) {
            case S_GAME:
                gotoScreen(this.mode == 1 ? S_LEVELS : S_HOME, -1);
                return true;
            case S_LEVELS:
            case S_SETTINGS:
                gotoScreen(S_HOME, -1);
                return true;
            case S_ABOUT:
            case S_ACH:
                gotoScreen(this.backScreen, -1);
                return true;
            default:
                return false;
        }
    }

    private void gotoScreen(int s) {
        gotoScreen(s, 1);
    }

    private void gotoScreen(int s, int dir) {
        if (this.prevBmp != null) {
            this.prevBmp.recycle();
            this.prevBmp = null;
        }
        this.prevBmp = captureFrame();
        this.transDir = dir;
        this.hadTrans = true;
        if (dir > 0 && (this.screen == S_HOME || this.screen == S_SETTINGS)) {
            this.backScreen = this.screen;
        }
        this.sfx.whoosh();
        this.screen = s;
        this.screenAge = 0.0f;
        this.pressId = 0;
        this.hitCount = 0;
        this.scrollY = 0.0f;
        this.scrollVel = 0.0f;
        this.activeRow = -1;
        this.resetArmed = false;
        this.flash = 0.0f;
        this.shake = 0.0f;
        if (s == S_SETTINGS) {
            syncRowAnim();
        }
        if (s == S_HOME) {
            this.best = Settings.bestFor(Settings.difficulty);
        }
    }

    private void configureGame() {
        int d = Settings.difficulty;
        if (this.mode == 1) {
            this.startMoves = Levels.moves(this.curLevel, d);
            this.activeTypes = Levels.types(this.curLevel, d);
            this.flipEvery = Settings.gravityFlip ? Levels.flipEvery(this.curLevel, d) : 0;
            this.levelTarget = Levels.target(this.curLevel, d);
        } else {
            this.startMoves = Levels.endlessMoves(d);
            this.activeTypes = Levels.endlessTypes(d);
            this.flipEvery = Settings.gravityFlip ? Levels.endlessFlip(d) : 0;
            this.levelTarget = 0;
            this.best = Settings.bestFor(d);
        }
        this.hintDelay = Settings.hints ? Levels.hintDelay(d) : 0.0f;
    }

    private void startGame(int m, int lvl) {
        this.mode = m;
        this.curLevel = lvl;
        gotoScreen(S_GAME);
        configureGame();
        if (Settings.bonusMoves > 0) {
            this.startMoves += Settings.bonusMoves;
            Settings.bonusMoves = 0;
        }
        Settings.cntGames++;
        Settings.save();
        newGame();
        this.bannerText = m == 1 ? "LEVEL " + (lvl + 1) : "GO!";
        this.bannerT = 1.5f;
    }

    private void winLevel() {
        float frac = this.startMoves > 0 ? ((float) this.moves) / this.startMoves : 0.0f;
        int st = frac >= 0.35f ? 3 : (frac >= 0.12f ? 2 : 1);
        this.starsEarned = st;
        this.starsShown = 0;
        this.levelWon = true;
        if (Settings.difficulty == 3) {
            Settings.hardWin = true;
        }
        if (st > Settings.stars[this.curLevel]) {
            Settings.stars[this.curLevel] = st;
            Settings.save();
        }
        this.phase = 7;
        this.overT = 0.0f;
        this.sfx.win();
        confetti();
        Settings.save();
        checkAchievements();
    }

    private void failLevel() {
        this.levelWon = false;
        this.starsEarned = 0;
        this.phase = 7;
        this.overT = 0.0f;
        this.sfx.over();
        Settings.save();
    }

    private String footerText() {
        if (this.mode == 1) {
            return this.flipEvery > 0
                    ? "Reach the goal before moves run out  -  gravity flips every " + this.flipEvery
                    : "Reach the goal before your moves run out";
        }
        return this.flipEvery > 0
                ? "Swipe tiles to match 3  -  gravity flips every " + this.flipEvery + " moves"
                : "Swipe tiles to match 3  -  gravity flip is off";
    }

    private void applyTheme() {
        int[] bg;
        int[] bl;
        switch (Settings.theme) {
            case 1:
                bg = new int[]{0xFF2B0F3F, 0xFF3A0E2C, 0xFF1A0A12};
                bl = new int[]{0xFFFF7A3D, 0xFFFF3D8B, 0xFFFFB347, 0xFF8E44FF};
                break;
            case 2:
                bg = new int[]{0xFF041B2D, 0xFF062B4A, 0xFF03111F};
                bl = new int[]{0xFF00C2FF, 0xFF00FFC6, 0xFF2F6BFF, 0xFF7B5CFF};
                break;
            case 3:
                bg = new int[]{0xFF14002B, 0xFF1E0040, 0xFF07000F};
                bl = new int[]{0xFFFF00E5, 0xFF00FF9D, 0xFFFFE600, 0xFF3D5AFF};
                break;
            default:
                bg = new int[]{-15070403, -16117194, -16446945};
                bl = new int[]{-53867, -16722689, -8704001, -13804545};
                break;
        }
        System.arraycopy(bg, 0, this.themeBg, 0, 3);
        System.arraycopy(bl, 0, this.blobColors, 0, 4);
        for (int i = 0; i < 4; i++) {
            this.blobPaints[i].setShader(new RadialGradient(0.0f, 0.0f, 1.0f, withAlpha(this.blobColors[i], 128), withAlpha(this.blobColors[i], 0), Shader.TileMode.CLAMP));
        }
        if (getHeight() > 0) {
            this.bgShader = new LinearGradient(0.0f, 0.0f, 0.0f, (float) getHeight(), this.themeBg, new float[]{0.0f, 0.55f, 1.0f}, Shader.TileMode.CLAMP);
        }
    }

    // ------------------------------------------------------------------ hit registry + per-frame UI state

    private void beginHits() {
        this.hitCount = 0;
    }

    private void addHit(int id, float l, float t2, float r, float b) {
        if (this.hitCount >= this.hitIds.length) {
            return;
        }
        int o = this.hitCount * 4;
        this.hitIds[this.hitCount] = id;
        this.hitRect[o] = l;
        this.hitRect[o + 1] = t2;
        this.hitRect[o + 2] = r;
        this.hitRect[o + 3] = b;
        this.hitCount++;
    }

    private void addHit(int id, RectF r) {
        addHit(id, r.left, r.top, r.right, r.bottom);
    }

    private int hitTest(float x, float y) {
        for (int i = this.hitCount - 1; i >= 0; i--) {
            int o = i * 4;
            if (x >= this.hitRect[o] && x <= this.hitRect[o + 2] && y >= this.hitRect[o + 1] && y <= this.hitRect[o + 3]) {
                return this.hitIds[i];
            }
        }
        return 0;
    }

    private void stepUi(float dt) {
        float k = Math.min(1.0f, 16.0f * dt);
        for (int i = 0; i < this.pressAnim.length; i++) {
            float target = (this.pressId != 0 && i == this.pressId && this.pressInside) ? 1.0f : 0.0f;
            if (this.pressAnim[i] != target) {
                this.pressAnim[i] += (target - this.pressAnim[i]) * k;
                if (Math.abs(target - this.pressAnim[i]) < 0.01f) {
                    this.pressAnim[i] = target;
                }
            }
        }
        for (int i = 0; i < this.wiggle.length; i++) {
            if (this.wiggle[i] > 0.0f) {
                this.wiggle[i] = Math.max(0.0f, this.wiggle[i] - dt * 2.2f);
            }
        }
        if (this.screen == S_SETTINGS) {
            float maxS = Math.max(0.0f, this.contentH - (this.listBottom - this.listTop));
            if (!this.touching) {
                this.scrollY += this.scrollVel * dt;
                this.scrollVel -= this.scrollVel * Math.min(1.0f, 4.5f * dt);
                if (Math.abs(this.scrollVel) < 8.0f) {
                    this.scrollVel = 0.0f;
                }
            }
            if (this.scrollY < 0.0f) {
                this.scrollY = 0.0f;
                this.scrollVel = 0.0f;
            } else if (this.scrollY > maxS) {
                this.scrollY = maxS;
                this.scrollVel = 0.0f;
            }
            for (int i = 0; i < ROW_KIND.length; i++) {
                int id = ROW_ID[i];
                int kd = ROW_KIND[i];
                if (kd == 1) {
                    this.rowAnim[id] += ((getSw(id) ? 1.0f : 0.0f) - this.rowAnim[id]) * Math.min(1.0f, 12.0f * dt);
                } else if (kd == 2) {
                    this.rowAnim[id] += (getSl(id) - this.rowAnim[id]) * Math.min(1.0f, 16.0f * dt);
                } else if (kd == 3) {
                    this.rowAnim[id] += (getSeg(id) - this.rowAnim[id]) * Math.min(1.0f, 11.0f * dt);
                }
            }
            if (this.resetArmed) {
                this.resetArmT -= dt;
                if (this.resetArmT <= 0.0f) {
                    this.resetArmed = false;
                }
            }
        }
    }

    private void syncRowAnim() {
        for (int i = 0; i < ROW_KIND.length; i++) {
            int id = ROW_ID[i];
            int kd = ROW_KIND[i];
            if (kd == 1) {
                this.rowAnim[id] = getSw(id) ? 1.0f : 0.0f;
            } else if (kd == 2) {
                this.rowAnim[id] = getSl(id);
            } else if (kd == 3) {
                this.rowAnim[id] = getSeg(id);
            }
        }
    }

    private boolean getSw(int id) {
        switch (id) {
            case SW_FLIP:
                return Settings.gravityFlip;
            case SW_HINTS:
                return Settings.hints;
            case SW_SOUND:
                return Settings.sound;
            case SW_HAPTIC:
                return Settings.haptics;
            case SW_SHAKE:
                return Settings.shake;
            default:
                return Settings.bgFx;
        }
    }

    private float getSl(int id) {
        if (id == SL_VOL) {
            return Settings.volume;
        }
        if (id == SL_SPEED) {
            return Settings.speed - 0.6f;
        }
        return Settings.particles;
    }

    private int getSeg(int id) {
        return id == SEG_DIFF ? Settings.difficulty : Settings.theme;
    }

    // ------------------------------------------------------------------ touch routing

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX();
        float y = e.getY();
        int a = e.getActionMasked();
        if (this.prevBmp != null && this.screenAge < TRANS_DUR) {
            return true;
        }
        if (this.popupKind != 0) {
            if (a == MotionEvent.ACTION_DOWN) {
                int pid = hitTest(x, y);
                if (pid == ID_P_OK || pid == ID_P_CANCEL) {
                    this.pressId = pid;
                    this.pressInside = true;
                    this.sfx.tap();
                } else {
                    this.pressId = 0;
                }
            } else if (this.pressId != 0) {
                if (a == MotionEvent.ACTION_MOVE) {
                    this.pressInside = hitTest(x, y) == this.pressId;
                } else if (a == MotionEvent.ACTION_UP) {
                    int pid = this.pressId;
                    this.pressId = 0;
                    if (hitTest(x, y) == pid) {
                        onButton(pid);
                    }
                } else if (a == MotionEvent.ACTION_CANCEL) {
                    this.pressId = 0;
                }
            }
            return true;
        }
        if (this.screen == S_SETTINGS) {
            return settingsTouch(e);
        }
        if (a == MotionEvent.ACTION_DOWN) {
            int id = hitTest(x, y);
            if (this.screen == S_GAME && this.phase == 7) {
                if ((id != ID_O_LEFT && id != ID_O_RIGHT && id != ID_O_SHARE) || this.overT <= 0.7f) {
                    id = 0;
                }
            }
            if (id != 0) {
                this.pressId = id;
                this.pressInside = true;
                this.sfx.tap();
                return true;
            }
            this.pressId = 0;
        } else if (this.pressId != 0) {
            if (a == MotionEvent.ACTION_MOVE) {
                this.pressInside = hitTest(x, y) == this.pressId;
            } else if (a == MotionEvent.ACTION_UP) {
                int id = this.pressId;
                this.pressId = 0;
                if (hitTest(x, y) == id) {
                    onButton(id);
                }
            } else if (a == MotionEvent.ACTION_CANCEL) {
                this.pressId = 0;
            }
            return true;
        }
        if (this.screen == S_GAME) {
            return gameTouch(e);
        }
        return true;
    }

    private void onButton(int id) {
        if (id >= ID_LEVEL0 && id < ID_LEVEL0 + Settings.LEVEL_COUNT) {
            int lv = id - ID_LEVEL0;
            if (Settings.unlocked(lv)) {
                startGame(1, lv);
            } else {
                this.wiggle[lv] = 1.0f;
                this.sfx.bad();
                if (Settings.haptics) {
                    tick();
                }
            }
            return;
        }
        switch (id) {
            case ID_HOME_ACH:
                gotoScreen(S_ACH);
                break;
            case ID_HOME_ABOUT:
                gotoScreen(S_ABOUT);
                break;
            case ID_INSTA:
                openUrl(INSTA_URL);
                break;
            case ID_SHARE_APP:
                shareText(shareAppText());
                break;
            case ID_UPDATE:
                checkUpdates(true);
                break;
            case ID_O_SHARE:
                shareText(shareScoreText());
                break;
            case ID_P_OK:
                popupOk();
                break;
            case ID_P_CANCEL:
                popupClose();
                break;
            case ID_PLAY:
                gotoScreen(S_LEVELS);
                break;
            case ID_ENDLESS:
                startGame(0, 0);
                break;
            case ID_SETTINGS:
                gotoScreen(S_SETTINGS);
                break;
            case ID_DIFF:
                Settings.difficulty = (Settings.difficulty + 1) % 4;
                Settings.save();
                this.best = Settings.bestFor(Settings.difficulty);
                break;
            case ID_BACK:
                handleBack();
                break;
            case ID_G_MENU:
                gotoScreen(this.mode == 1 ? S_LEVELS : S_HOME);
                break;
            case ID_G_SOUND:
                Settings.sound = !Settings.sound;
                this.sfx.setEnabled(Settings.sound);
                Settings.save();
                if (Settings.sound) {
                    this.sfx.tap();
                }
                break;
            case ID_G_RESTART:
                startGame(this.mode, this.curLevel);
                break;
            case ID_O_LEFT:
                if (this.mode == 1) {
                    if (this.levelWon) {
                        startGame(1, this.curLevel);
                    } else {
                        gotoScreen(S_LEVELS);
                    }
                } else {
                    gotoScreen(S_HOME);
                }
                break;
            case ID_O_RIGHT:
                if (this.mode == 1) {
                    if (this.levelWon) {
                        if (this.curLevel < Settings.LEVEL_COUNT - 1) {
                            startGame(1, this.curLevel + 1);
                        } else {
                            gotoScreen(S_LEVELS);
                        }
                    } else {
                        startGame(1, this.curLevel);
                    }
                } else {
                    startGame(0, 0);
                }
                break;
            default:
                break;
        }
    }

    // ------------------------------------------------------------------ settings screen: geometry + touch

    private float rowHeight(int i, float u) {
        switch (ROW_KIND[i]) {
            case 0:
                return u * 4.4f;
            case 1:
                return u * 7.4f;
            case 2:
                return u * 10.2f;
            case 3:
                return ROW_ID[i] == SEG_DIFF ? u * 15.5f : u * 12.4f;
            case 4:
                return u * 7.8f;
            default:
                return u * 15.0f;
        }
    }

    private void settingsGeom() {
        float H = getHeight();
        float u = H / 100.0f;
        this.listTop = H * 0.125f;
        this.listBottom = H * 0.985f;
        float y = 0.0f;
        for (int i = 0; i < ROW_KIND.length; i++) {
            this.rowH[i] = rowHeight(i, u);
            this.rowTop[i] = this.listTop + y - this.scrollY;
            y += this.rowH[i] + (ROW_KIND[i] == 0 ? 0.0f : u * 1.4f);
        }
        this.contentH = y;
    }

    private RectF ctlRect(int i) {
        float W = getWidth();
        float H = getHeight();
        float left = W * 0.045f;
        float right = W - left;
        float top = this.rowTop[i];
        float h = this.rowH[i];
        switch (ROW_KIND[i]) {
            case 1: {
                float sw = W * 0.17f;
                float sh = sw * 0.5f;
                this.ctl.set(right - W * 0.04f - sw, top + (h - sh) / 2.0f, right - W * 0.04f, top + (h + sh) / 2.0f);
                break;
            }
            case 2: {
                float th = H * 0.011f;
                float cy = top + h * 0.68f;
                this.ctl.set(left + W * 0.075f, cy - th / 2.0f, right - W * 0.075f, cy + th / 2.0f);
                break;
            }
            case 3: {
                float sh = H * 0.052f;
                float sy = ROW_ID[i] == SEG_DIFF ? top + h * 0.27f : top + h * 0.40f;
                this.ctl.set(left + W * 0.04f, sy, right - W * 0.04f, sy + sh);
                break;
            }
            default:
                this.ctl.set(left, top, right, top + h);
                break;
        }
        return this.ctl;
    }

    private int rowAt(float x, float y) {
        float W = getWidth();
        if (x < W * 0.045f || x > W * 0.955f) {
            return -1;
        }
        for (int i = 0; i < ROW_KIND.length; i++) {
            if (ROW_KIND[i] != 0 && y >= this.rowTop[i] && y <= this.rowTop[i] + this.rowH[i]) {
                return i;
            }
        }
        return -1;
    }

    private void setSliderFromX(int row, float x) {
        int id = ROW_ID[row];
        RectF r = ctlRect(row);
        float h = r.height();
        float v = Ui.clamp01((x - (r.left + h / 2.0f)) / Math.max(1.0f, r.width() - h));
        if (id == SL_VOL) {
            Settings.volume = v;
            this.sfx.setVolume(v);
        } else if (id == SL_SPEED) {
            Settings.speed = Math.round((0.6f + v) * 10.0f) / 10.0f;
        } else {
            Settings.particles = v;
        }
    }

    private void setSegFromX(int row, float x) {
        RectF r = ctlRect(row);
        float pad = r.height() * 0.1f;
        float sw = (r.width() - 2.0f * pad) / 4.0f;
        int idx = clampInt((int) Math.floor((x - r.left - pad) / sw), 0, 3);
        int id = ROW_ID[row];
        if (id == SEG_DIFF) {
            if (Settings.difficulty != idx) {
                Settings.difficulty = idx;
                this.rowFlash[id] = 1.0f;
                Settings.save();
                this.best = Settings.bestFor(idx);
                this.sfx.tap();
            }
        } else if (Settings.theme != idx) {
            Settings.theme = idx;
            this.rowFlash[id] = 1.0f;
            applyTheme();
            Settings.save();
            this.sfx.tap();
        }
    }

    private void applySwitch(int id) {
        this.rowFlash[id] = 1.0f;
        switch (id) {
            case SW_FLIP:
                Settings.gravityFlip = !Settings.gravityFlip;
                break;
            case SW_HINTS:
                Settings.hints = !Settings.hints;
                break;
            case SW_SOUND:
                Settings.sound = !Settings.sound;
                this.sfx.setEnabled(Settings.sound);
                break;
            case SW_HAPTIC:
                Settings.haptics = !Settings.haptics;
                break;
            case SW_SHAKE:
                Settings.shake = !Settings.shake;
                break;
            default:
                Settings.bgFx = !Settings.bgFx;
                break;
        }
        Settings.save();
        this.sfx.tap();
        if (id == SW_HAPTIC && Settings.haptics) {
            tick();
        }
    }

    private void tapReset() {
        if (!this.resetArmed) {
            this.resetArmed = true;
            this.resetArmT = 3.0f;
            this.sfx.tap();
            return;
        }
        this.resetArmed = false;
        Settings.resetProgress();
        this.best = 0;
        this.sfx.bad();
        Toast.makeText(getContext(), "Progress reset", Toast.LENGTH_SHORT).show();
    }

    private boolean settingsTouch(MotionEvent e) {
        float x = e.getX();
        float y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                this.setDownX = x;
                this.setDownY = y;
                this.setLastY = y;
                this.setLastT = e.getEventTime();
                this.setMoved = false;
                this.touching = true;
                this.scrollVel = 0.0f;
                this.activeRow = -1;
                this.pressId = 0;
                if (hitTest(x, y) == ID_BACK) {
                    this.pressId = ID_BACK;
                    this.pressInside = true;
                    this.sfx.tap();
                    return true;
                }
                if (y < this.listTop || y > this.listBottom) {
                    return true;
                }
                int row = rowAt(x, y);
                if (row >= 0) {
                    int kind = ROW_KIND[row];
                    if (kind == 2) {
                        if (y >= this.rowTop[row] + this.rowH[row] * 0.35f) {
                            this.activeRow = row;
                            setSliderFromX(row, x);
                        }
                    } else if (kind == 3) {
                        RectF r = ctlRect(row);
                        if (x >= r.left - dp * 6.0f && x <= r.right + dp * 6.0f && y >= r.top - dp * 6.0f && y <= r.bottom + dp * 6.0f) {
                            this.activeRow = row;
                            setSegFromX(row, x);
                        }
                    } else if (kind == 1 || kind == 4 || kind == 5) {
                        this.activeRow = row;
                        this.pressId = ROW_ID[row];
                        this.pressInside = true;
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (this.pressId == ID_BACK) {
                    this.pressInside = hitTest(x, y) == ID_BACK;
                    return true;
                }
                if (this.activeRow >= 0) {
                    int kind = ROW_KIND[this.activeRow];
                    if (kind == 2) {
                        setSliderFromX(this.activeRow, x);
                        return true;
                    }
                    if (kind == 3) {
                        setSegFromX(this.activeRow, x);
                        return true;
                    }
                    if (Math.abs(y - this.setDownY) > dp * 10.0f) {
                        this.activeRow = -1;
                        this.pressId = 0;
                        this.setMoved = true;
                    }
                }
                if (Math.abs(y - this.setDownY) > dp * 8.0f) {
                    this.setMoved = true;
                }
                if (this.setMoved) {
                    float dy = y - this.setLastY;
                    long nowT = e.getEventTime();
                    float dtSec = Math.max(0.001f, (nowT - this.setLastT) / 1000.0f);
                    this.scrollY -= dy;
                    this.scrollVel = Math.max(-6000.0f, Math.min(6000.0f, -dy / dtSec));
                    this.setLastT = nowT;
                }
                this.setLastY = y;
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                this.touching = false;
                boolean up = e.getActionMasked() == MotionEvent.ACTION_UP;
                if (this.pressId == ID_BACK) {
                    this.pressId = 0;
                    if (up && hitTest(x, y) == ID_BACK) {
                        handleBack();
                    }
                    return true;
                }
                if (this.activeRow >= 0) {
                    int kind = ROW_KIND[this.activeRow];
                    int row = this.activeRow;
                    if (up && (kind == 1 || kind == 4 || kind == 5) && rowAt(x, y) == row && !this.setMoved) {
                        if (kind == 1) {
                            applySwitch(ROW_ID[row]);
                        } else {
                            settingsButton(ROW_ID[row]);
                        }
                    } else if (kind == 2 || kind == 3) {
                        this.rowFlash[ROW_ID[row]] = 0.7f;
                        Settings.save();
                        this.sfx.tap();
                    }
                }
                this.activeRow = -1;
                this.pressId = 0;
                if (!this.setMoved) {
                    this.scrollVel = 0.0f;
                }
                return true;
            }
            default:
                return true;
        }
    }

    // ------------------------------------------------------------------ in-game extras

    private void drawGameButtons(Canvas c) {
        miniButton(c, this.menuGlass, "MENU", ID_G_MENU);
        miniButton(c, this.restartGlass, "RESTART", ID_G_RESTART);
        if (this.soundGlass != null) {
            addHit(ID_G_SOUND, this.soundGlass.getRect());
        }
    }

    private void miniButton(Canvas c, Glass g, String label, int id) {
        if (g == null) {
            return;
        }
        RectF r = g.getRect();
        float pa = this.pressAnim[id];
        c.save();
        float s = 1.0f - 0.07f * pa;
        c.scale(s, s, r.centerX(), r.centerY());
        drawGlass(c, g);
        drawText$default(this, c, label, r.centerX(), r.centerY() + (r.height() * 0.17f), r.height() * 0.38f, -1, null, 64, null);
        c.restore();
        addHit(id, r);
    }

    private void drawTargetCard(Canvas c, Glass g) {
        drawGlass(c, g);
        RectF r = g.getRect();
        float h = r.height();
        drawText$default(this, c, "LEVEL " + (this.curLevel + 1) + " GOAL", r.centerX(), r.top + (0.34f * h), h * 0.17f, -1426063361, null, 64, null);
        drawText$default(this, c, String.valueOf(this.levelTarget), r.centerX(), r.top + (0.7f * h), h * 0.34f, -10929, null, 64, null);
        this.tmp.set(r.left + r.width() * 0.1f, r.top + h * 0.8f, r.right - r.width() * 0.1f, r.top + h * 0.92f);
        float prog = this.levelTarget > 0 ? Math.min(1.0f, this.displayScore / this.levelTarget) : 0.0f;
        Ui.liquidBar(c, this.tmp, prog, this.time, 0xFFFFD54F, 0xFFFF7A3D, this.dp);
    }

    // ------------------------------------------------------------------ shared screen pieces

    private void drawFloaters(Canvas c, float intensity) {
        float W = getWidth();
        float H = getHeight();
        for (int i = 0; i < 9; i++) {
            float sp = 0.012f + (i % 4) * 0.006f;
            float py = (((i * 0.137f + 0.25f - this.time * sp) % 1.0f) + 1.0f) % 1.0f;
            float px = 0.1f + ((i * 0.331f) % 0.8f) + ((float) Math.sin(this.time * 0.6f + i)) * 0.03f;
            float rad = W * (0.045f + (i % 3) * 0.018f);
            float rot = this.time * (20.0f + i * 7.0f) * ((i % 2 == 0) ? 1.0f : -1.0f);
            drawTile(c, i % this.types, px * W, py * H, rad, 1.0f, 1.0f, 0.25f, 0.28f * intensity, rot);
        }
    }

    private Shader titleShimmer() {
        float W = getWidth();
        return Ui.shimmer(W * 0.2f, W * 0.8f, this.time);
    }

    private void drawHeader(Canvas c, String title, String right) {
        float W = getWidth();
        float H = getHeight();
        float bs = W * 0.115f;
        float bx = W * 0.04f;
        float by = H * 0.028f;
        this.tmp.set(bx, by, bx + bs, by + bs);
        float pr = this.pressAnim[ID_BACK];
        c.save();
        float sc = 1.0f - 0.08f * pr;
        c.scale(sc, sc, this.tmp.centerX(), this.tmp.centerY());
        Ui.panel(c, this.tmp, bs / 2.0f, this.dp, 1.0f);
        Ui.chevronLeft(c, this.tmp.centerX(), this.tmp.centerY(), bs * 0.34f, 0xFFFFFFFF, this.dp);
        c.restore();
        addHit(ID_BACK, bx - bs * 0.2f, by - bs * 0.2f, bx + bs * 1.2f, by + bs * 1.2f);
        float ea = Ui.clamp01(this.screenAge / 0.4f);
        Ui.textShader(c, title, W / 2.0f, by + bs * 0.68f, W * 0.055f, titleShimmer(), Paint.Align.CENTER, 0.12f, ea);
        if (right != null) {
            float tsz = W * 0.04f;
            float tw = Ui.measure(right, tsz, 0.04f);
            float rx = W - W * 0.045f;
            Ui.text(c, right, rx, by + bs * 0.66f, tsz, Ui.alpha(0xFFFFD54F, ea), Paint.Align.RIGHT, 0.04f);
            Ui.star(c, rx - tw - W * 0.04f, by + bs * 0.5f, W * 0.027f, Ui.alpha(0xFFFFD54F, ea), 0, 0.0f, this.dp);
        }
    }

    // ------------------------------------------------------------------ HOME

    // ------------------------------------------------------------------ LEVEL SELECT

    private void drawLevels(Canvas c) {
        float W = getWidth();
        float H = getHeight();
        drawFloaters(c, 0.7f);
        drawHeader(c, "SELECT LEVEL", Settings.totalStars() + "/" + (Settings.LEVEL_COUNT * 3));
        int cols = 5;
        int rows = 6;
        float gridW = W * 0.92f;
        float padG = W * 0.03f;
        float gap = W * 0.022f;
        float cell = (gridW - 2.0f * padG - (cols - 1) * gap) / cols;
        float cellH = cell * 1.15f;
        float gridH = 2.0f * padG + rows * cellH + (rows - 1) * gap;
        float left = (W - gridW) / 2.0f;
        float top = Math.max(H * 0.135f, H * 0.5f - gridH / 2.0f);
        float pe = Ui.easeOutCubic(this.screenAge / 0.35f);
        this.tmp.set(left, top, left + gridW, top + gridH);
        Ui.panel(c, this.tmp, W * 0.05f, this.dp, 0.7f * pe);
        int next = Settings.nextLevel();
        for (int i = 0; i < Settings.LEVEL_COUNT; i++) {
            int r = i / cols;
            int col = i % cols;
            float x = left + padG + col * (cell + gap);
            float y = top + padG + r * (cellH + gap);
            float e = Ui.easeOutBack((this.screenAge - 0.08f - (r + col) * 0.035f) / 0.4f);
            if (e <= 0.0f) {
                continue;
            }
            float cx = x + cell / 2.0f;
            float cy = y + cellH / 2.0f;
            boolean unl = Settings.unlocked(i);
            float wig = this.wiggle[i];
            float dx = ((float) Math.sin(wig * 40.0f)) * wig * this.dp * 7.0f;
            float pa = this.pressAnim[ID_LEVEL0 + i];
            float s2 = Math.max(0.01f, (0.4f + 0.6f * e) * (1.0f - 0.08f * pa));
            c.save();
            c.translate(dx, 0.0f);
            c.scale(s2, s2, cx, cy);
            if (i == next) {
                float pulse = 0.5f + 0.5f * (float) Math.sin(this.time * 3.0f);
                Ui.glow(c, cx, cy, cell * 0.95f, Ui.alpha(0xFFFFD54F, 0.25f + 0.25f * pulse));
            }
            this.tmp.set(x, y, x + cell, y + cellH);
            Ui.panel(c, this.tmp, cell * 0.26f, this.dp, unl ? 1.0f : 0.45f);
            if (unl) {
                Ui.text(c, String.valueOf(i + 1), cx, y + cellH * 0.56f, cell * 0.42f, 0xFFFFFFFF, Paint.Align.CENTER, 0.02f);
                for (int sI = 0; sI < 3; sI++) {
                    boolean got = Settings.stars[i] > sI;
                    Ui.star(c, cx + (sI - 1) * cell * 0.27f, y + cellH * 0.8f, cell * 0.12f, got ? 0xFFFFD54F : 0x33FFFFFF, 0, 0.0f, this.dp);
                }
            } else {
                Ui.lock(c, cx, cy, cell * 0.36f, 0x99FFFFFF, this.dp);
            }
            c.restore();
            addHit(ID_LEVEL0 + i, x, y, x + cell, y + cellH);
        }
        float ia = Ui.clamp01((this.screenAge - 0.5f) / 0.4f);
        Ui.text(c, "Reach the goal score before you run out of moves", W / 2.0f, top + gridH + H * 0.04f, W * 0.032f, Ui.alpha(0xFFFFFFFF, 0.7f * ia), Paint.Align.CENTER, 0.02f);
        Ui.text(c, "DIFFICULTY: " + Settings.DIFF_NAMES[Settings.difficulty], W / 2.0f, top + gridH + H * 0.075f, W * 0.036f, Ui.alpha(0xFFFFD54F, ia), Paint.Align.CENTER, 0.08f);
    }

    // ------------------------------------------------------------------ SETTINGS

    private static int diffColor(float pos) {
        int a = clampInt((int) Math.floor(pos), 0, 3);
        int b = clampInt(a + 1, 0, 3);
        return Ui.mix(DIFF_COL[a], DIFF_COL[b], pos - a);
    }

    private static int themeColor(float pos) {
        int a = clampInt((int) Math.floor(pos), 0, 3);
        int b = clampInt(a + 1, 0, 3);
        return Ui.mix(THEME_COL[a], THEME_COL[b], pos - a);
    }

    private void drawSettings(Canvas c) {
        float W = getWidth();
        float H = getHeight();
        drawHeader(c, "SETTINGS", null);
        settingsGeom();
        float mx = W * 0.045f;
        c.save();
        c.clipRect(0.0f, this.listTop, W, this.listBottom);
        for (int i = 0; i < ROW_KIND.length; i++) {
            float top = this.rowTop[i];
            float h = this.rowH[i];
            if (top + h < this.listTop - 6.0f || top > this.listBottom + 6.0f) {
                continue;
            }
            float e = Ui.clamp01((this.screenAge - 0.05f - Math.min(i, 8) * 0.04f) / 0.35f);
            if (e <= 0.0f) {
                continue;
            }
            float off = (1.0f - Ui.easeOutCubic(e)) * this.dp * 26.0f;
            int layer = -1;
            if (e < 1.0f) {
                layer = c.saveLayerAlpha(0.0f, top - this.dp * 40.0f, W, top + h + this.dp * 40.0f, (int) (255.0f * e));
            }
            c.save();
            c.translate(0.0f, off);
            drawRow(c, i, mx, top, W - 2.0f * mx, h);
            c.restore();
            if (layer >= 0) {
                c.restoreToCount(layer);
            }
        }
        c.restore();
        float viewH = this.listBottom - this.listTop;
        if (this.contentH > viewH + 1.0f) {
            float th = viewH * viewH / this.contentH;
            float ty = this.listTop + (this.scrollY / (this.contentH - viewH)) * (viewH - th);
            this.plain.setShader(null);
            this.plain.setColor(0x55FFFFFF);
            c.drawRoundRect(W - this.dp * 5.0f, ty, W - this.dp * 2.0f, ty + th, this.dp * 2.0f, this.dp * 2.0f, this.plain);
        }
    }

    private void drawRow(Canvas c, int i, float left, float top, float w, float h) {
        float W = getWidth();
        float H = getHeight();
        int kind = ROW_KIND[i];
        int id = ROW_ID[i];
        if (kind == 0) {
            Ui.text(c, ROW_LABEL[i], left + w * 0.02f, top + h * 0.82f, H * 0.0165f, 0xFF8FD8FF, Paint.Align.LEFT, 0.22f);
            return;
        }
        this.tmp.set(left, top, left + w, top + h);
        float rad = Math.min(h * 0.26f, W * 0.05f);
        if (kind == 4) {
            String label = ROW_LABEL[i];
            int tint = 0xFFFFFFFF;
            boolean prim = false;
            if (id == BTN_RESET) {
                label = this.resetArmed ? "TAP AGAIN TO CONFIRM" : "RESET PROGRESS";
                tint = 0xFFFF4D6D;
                prim = true;
            } else if (id == BTN_ABOUT) {
                tint = 0xFFE1306C;
                prim = true;
            }
            Ui.button(c, this.tmp, label, this.pressAnim[id], this.time, tint, prim, this.dp);
            return;
        }
        if (kind == 5) {
            c.save();
            float s5 = 1.0f - 0.02f * this.pressAnim[id];
            c.scale(s5, s5, this.tmp.centerX(), this.tmp.centerY());
            Ui.panel(c, this.tmp, rad, this.dp, 0.9f);
            float cx = this.tmp.centerX();
            Ui.text(c, "FLIP MATCH  v" + Updater.CURRENT_NAME, cx, top + h * 0.22f, W * 0.045f, 0xFFFFFFFF, Paint.Align.CENTER, 0.1f);
            Ui.text(c, "DEVELOPED & CREATED BY", cx, top + h * 0.42f, W * 0.026f, 0xBBFFFFFF, Paint.Align.CENTER, 0.2f);
            Ui.textShader(c, "AYUSH VAITAGE", cx, top + h * 0.65f, W * 0.062f, titleShimmer(), Paint.Align.CENTER, 0.08f, 1.0f);
            Ui.text(c, "TAP TO OPEN INSTAGRAM", cx, top + h * 0.86f, W * 0.026f, 0xFFFF9EC4, Paint.Align.CENTER, 0.18f);
            c.restore();
            return;
        }
        float press = (kind == 1) ? this.pressAnim[id] : 0.0f;
        c.save();
        float s = 1.0f - 0.015f * press;
        c.scale(s, s, this.tmp.centerX(), this.tmp.centerY());
        Ui.panel(c, this.tmp, rad, this.dp, 0.9f);
        float fl = this.rowFlash[id];
        if (fl > 0.0f) {
            this.plain.setShader(null);
            this.plain.setColor(Ui.alpha(0x55FFFFFF, fl));
            c.drawRoundRect(this.tmp, rad, rad, this.plain);
        }
        float lx = left + w * 0.05f;
        float lsz = H * 0.0195f;
        if (kind == 1) {
            Ui.text(c, ROW_LABEL[i], lx, top + h * 0.5f + lsz * 0.36f, lsz, 0xFFFFFFFF, Paint.Align.LEFT, 0.04f);
            Ui.glassSwitch(c, ctlRect(i), this.rowAnim[id], this.time, this.dp);
        } else if (kind == 2) {
            float disp = this.rowAnim[id];
            float target = getSl(id);
            Ui.text(c, ROW_LABEL[i], lx, top + h * 0.33f, lsz, 0xFFFFFFFF, Paint.Align.LEFT, 0.04f);
            String vs;
            int ca;
            int cb;
            if (id == SL_VOL) {
                vs = Math.round(Settings.volume * 100.0f) + "%";
                ca = 0xFF2EE6FF;
                cb = 0xFF3D7BFF;
            } else if (id == SL_SPEED) {
                int sx10 = Math.round(Settings.speed * 10.0f);
                vs = (sx10 / 10) + "." + (sx10 % 10) + "x";
                ca = 0xFFFFD54F;
                cb = 0xFFFF7A3D;
            } else {
                vs = Math.round(Settings.particles * 100.0f) + "%";
                ca = 0xFFFF7AC8;
                cb = 0xFF8E5CFF;
            }
            Ui.text(c, vs, left + w - w * 0.05f, top + h * 0.33f, lsz, ca, Paint.Align.RIGHT, 0.04f);
            float squash = Math.max(-0.4f, Math.min(0.4f, (target - disp) * 5.0f));
            Ui.liquidSlider(c, ctlRect(i), disp, this.time, squash, ca, cb, this.dp);
        } else if (kind == 3) {
            boolean isDiff = id == SEG_DIFF;
            Ui.text(c, ROW_LABEL[i], lx, top + h * (isDiff ? 0.18f : 0.24f), lsz, 0xFFFFFFFF, Paint.Align.LEFT, 0.04f);
            float pos = this.rowAnim[id];
            RectF r = ctlRect(i);
            if (isDiff) {
                Ui.segmented(c, r, Settings.DIFF_NAMES, pos, this.time, this.dp, diffColor(pos));
                Ui.text(c, Levels.describe(Settings.difficulty), this.tmp.centerX(), top + h * 0.9f, H * 0.0145f, 0xBBFFFFFF, Paint.Align.CENTER, 0.02f);
            } else {
                Ui.segmented(c, r, Settings.THEME_NAMES, pos, this.time, this.dp, themeColor(pos));
            }
        }
        c.restore();
    }

    // ------------------------------------------------------------------ game over / level complete overlay

    // =====================================================================
    //  v3.1 additions: page transitions, About, Achievements, popups,
    //  daily reward, update check, share.   By Ayush Vaitage
    // =====================================================================

    private static final int P_UPDATE = 1;
    private static final int P_NOTICE = 2;
    private static final int P_DAILY = 3;

    private Bitmap prevBmp;
    private int transDir = 1;
    private int backScreen = S_HOME;
    private boolean hadTrans;
    private final Paint bmpPaint = new Paint(1);
    private final RectF tmp3 = new RectF();
    private final float[] rowFlash = new float[256];
    private int popupKind;
    private float popupAge;
    private String popupTitle = "";
    private String popupBody = "";
    private String popupOk = "OK";
    private String popupCancel;
    private boolean updShown;
    private boolean noticeShown;
    private boolean dailyShown;
    private final ArrayList<String> toastQ = new ArrayList<String>();
    private String toastText = "";
    private float toastT;

    // ------------------------------------------------------------------ frame drawing with page transitions

    private void renderForeground(Canvas canvas) {
        switch (this.screen) {
            case S_GAME:
                canvas.save();
                if (Settings.shake && this.shake > 0.0f) {
                    canvas.translate((this.rnd.nextFloat() - 0.5f) * this.shake * this.cell * 0.4f, (this.rnd.nextFloat() - 0.5f) * this.shake * this.cell * 0.4f);
                }
                drawHud(canvas);
                drawBoard(canvas);
                drawParticles(canvas);
                canvas.restore();
                drawBanner(canvas);
                if (this.flash > 0.0f) {
                    this.plain.setShader(null);
                    this.plain.setColor(withAlpha(-1, (int) (this.flash * 110)));
                    canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.plain);
                }
                if (this.phase == 7) {
                    drawOver(canvas);
                }
                break;
            case S_HOME:
                drawHome(canvas);
                break;
            case S_LEVELS:
                drawLevels(canvas);
                break;
            case S_SETTINGS:
                drawSettings(canvas);
                break;
            case S_ABOUT:
                drawAbout(canvas);
                break;
            default:
                drawAch(canvas);
                break;
        }
    }

    private Bitmap captureFrame() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) {
            return null;
        }
        try {
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            int savedHits = this.hitCount;
            renderForeground(cv);
            this.hitCount = savedHits;
            return b;
        } catch (Throwable t2) {
            return null;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        long now = System.nanoTime();
        if (this.lastNanos == 0) {
            this.lastNanos = now;
        }
        float dt = (now - this.lastNanos) / 1.0E9f;
        this.lastNanos = now;
        if (dt > 0.05f) {
            dt = 0.05f;
        }
        if (dt < 0.0f) {
            dt = 0.0f;
        }
        this.uiDt = dt;
        this.screenAge += dt;
        beginHits();
        stepUi(dt);
        stepExtras(dt);
        if (this.screen == S_GAME) {
            update(dt * Settings.speed);
        } else {
            this.time += dt;
        }
        drawBackground(canvas);
        float W = getWidth();
        float H = getHeight();
        boolean trans = this.prevBmp != null && this.screenAge < TRANS_DUR;
        if (!trans && this.prevBmp != null) {
            this.prevBmp.recycle();
            this.prevBmp = null;
        }
        if (trans) {
            float e = Ui.easeInOut(this.screenAge / TRANS_DUR);
            int dir = this.transDir;
            this.bmpPaint.setAlpha((int) (255.0f * (1.0f - Ui.clamp01(e * 1.15f))));
            canvas.save();
            canvas.translate(-dir * W * 0.2f * e, 0.0f);
            float so = 1.0f - 0.05f * e;
            canvas.scale(so, so, W / 2.0f, H / 2.0f);
            canvas.drawBitmap(this.prevBmp, 0.0f, 0.0f, this.bmpPaint);
            canvas.restore();
            canvas.save();
            canvas.translate(dir * W * 0.26f * (1.0f - e), 0.0f);
            float sn = 0.94f + 0.06f * e;
            canvas.scale(sn, sn, W / 2.0f, H / 2.0f);
            int layer = canvas.saveLayerAlpha(0.0f, 0.0f, W, H, (int) (255.0f * Ui.clamp01(e * 1.5f)));
            renderForeground(canvas);
            canvas.restoreToCount(layer);
            canvas.restore();
            Ui.sweep(canvas, W, H, e);
        } else {
            renderForeground(canvas);
            if (!this.hadTrans) {
                float veil = 1.0f - Ui.clamp01(this.screenAge / 0.35f);
                if (veil > 0.0f) {
                    this.plain.setShader(null);
                    this.plain.setColor(withAlpha(0xFF050A14, (int) (255 * veil * 0.85f)));
                    canvas.drawRect(0.0f, 0.0f, W, H, this.plain);
                }
            }
        }
        drawPopup(canvas);
        drawToast(canvas);
        postInvalidateOnAnimation();
    }

    private void stepExtras(float dt) {
        for (int i = 0; i < this.rowFlash.length; i++) {
            if (this.rowFlash[i] > 0.0f) {
                this.rowFlash[i] = Math.max(0.0f, this.rowFlash[i] - dt * 2.4f);
            }
        }
        if (this.popupKind != 0) {
            this.popupAge += dt;
        }
        if (this.toastT > 0.0f) {
            this.toastT -= dt;
        }
        if (this.toastT <= 0.0f && !this.toastQ.isEmpty()) {
            this.toastText = this.toastQ.remove(0);
            this.toastT = 3.0f;
            this.sfx.reward();
        }
        maybeShowPopup();
    }

    // ------------------------------------------------------------------ popups (update / news / daily reward)

    private void showPopup(int kind, String title, String body, String ok, String cancel) {
        this.popupKind = kind;
        this.popupAge = 0.0f;
        this.popupTitle = title;
        this.popupBody = body;
        this.popupOk = ok;
        this.popupCancel = cancel;
        this.pressId = 0;
        this.sfx.notifyChime();
    }

    private void popupClose() {
        this.popupKind = 0;
        this.pressId = 0;
    }

    private void popupOk() {
        int k = this.popupKind;
        popupClose();
        if (k == P_UPDATE) {
            if (Updater.apkUrl.length() > 0) {
                openUrl(Updater.apkUrl);
            }
        } else if (k == P_NOTICE) {
            Settings.seenAnn = Updater.announcementId;
            Settings.save();
        } else if (k == P_DAILY) {
            int r = Settings.claimDaily();
            this.sfx.reward();
            Toast.makeText(getContext(), "+" + r + " bonus moves for your next game!", Toast.LENGTH_SHORT).show();
            checkAchievements();
        }
    }

    private void maybeShowPopup() {
        if (this.popupKind != 0 || this.screen != S_HOME || this.screenAge < 1.0f || this.prevBmp != null) {
            return;
        }
        if (Updater.done && Updater.updateAvailable() && !this.updShown) {
            this.updShown = true;
            showPopup(P_UPDATE, "UPDATE AVAILABLE", "Version " + Updater.versionName + " is ready.\n" + Updater.message, "UPDATE", "LATER");
            return;
        }
        if (Updater.done && Updater.ok && Updater.announcement.length() > 0 && Updater.announcementId > Settings.seenAnn && !this.noticeShown) {
            this.noticeShown = true;
            showPopup(P_NOTICE, "NEWS", Updater.announcement, "GOT IT", null);
            return;
        }
        if (Settings.dailyAvailable() && !this.dailyShown) {
            this.dailyShown = true;
            int next = (Settings.lastClaimDay == Settings.today() - 1) ? Settings.streak + 1 : 1;
            showPopup(P_DAILY, "DAILY REWARD", "Day " + next + " streak!\nGet +" + Math.min(8, 2 + next) + " bonus moves for your next game.", "CLAIM", null);
        }
    }

    private ArrayList<String> wrap(String text, float size, float maxW) {
        ArrayList<String> out = new ArrayList<String>();
        String[] paras = text.split("\n");
        for (int p = 0; p < paras.length; p++) {
            String[] words = paras[p].split(" ");
            String cur = "";
            for (int i = 0; i < words.length; i++) {
                String test = cur.length() == 0 ? words[i] : cur + " " + words[i];
                if (cur.length() > 0 && Ui.measure(test, size, 0.02f) > maxW) {
                    out.add(cur);
                    cur = words[i];
                } else {
                    cur = test;
                }
            }
            out.add(cur);
        }
        return out;
    }

    private void drawPopup(Canvas c) {
        if (this.popupKind == 0) {
            return;
        }
        float W = getWidth();
        float H = getHeight();
        float e = Ui.easeOutBack(this.popupAge / 0.45f);
        float a = Ui.clamp01(this.popupAge / 0.25f);
        this.plain.setShader(null);
        this.plain.setColor(Ui.alpha(0xFF000000, 0.62f * a));
        c.drawRect(0.0f, 0.0f, W, H, this.plain);
        float cw = W * 0.84f;
        float tsz = W * 0.056f;
        float bsz = W * 0.04f;
        float lh = bsz * 1.4f;
        ArrayList<String> lines = wrap(this.popupBody, bsz, cw * 0.84f);
        float btnH = H * 0.06f;
        float ch = tsz * 2.6f + lines.size() * lh + btnH * 1.9f;
        float cx = W / 2.0f;
        float cy = H / 2.0f;
        float x0 = cx - cw / 2.0f;
        float y0 = cy - ch / 2.0f;
        c.save();
        float sc = 0.7f + 0.3f * Math.min(1.08f, e);
        c.scale(sc, sc, cx, cy);
        int layer = c.saveLayerAlpha(0.0f, 0.0f, W, H, (int) (255.0f * a));
        this.tmp.set(x0, y0, x0 + cw, y0 + ch);
        Ui.panel(c, this.tmp, W * 0.06f, this.dp, 1.3f);
        Ui.textShader(c, this.popupTitle, cx, y0 + tsz * 1.6f, tsz, titleShimmer(), Paint.Align.CENTER, 0.1f, 1.0f);
        float ty = y0 + tsz * 2.6f + lh * 0.6f;
        for (int i = 0; i < lines.size(); i++) {
            Ui.text(c, lines.get(i), cx, ty, bsz, 0xE6FFFFFF, Paint.Align.CENTER, 0.02f);
            ty += lh;
        }
        float by = y0 + ch - btnH * 1.4f;
        if (this.popupCancel != null) {
            float bw = cw * 0.38f;
            this.tmp.set(x0 + cw * 0.08f, by, x0 + cw * 0.08f + bw, by + btnH);
            Ui.button(c, this.tmp, this.popupCancel, this.pressAnim[ID_P_CANCEL], this.time, 0xFFFFFFFF, false, this.dp);
            addHit(ID_P_CANCEL, this.tmp);
            this.tmp2.set(x0 + cw * 0.92f - bw, by, x0 + cw * 0.92f, by + btnH);
            Ui.button(c, this.tmp2, this.popupOk, this.pressAnim[ID_P_OK], this.time, 0xFF1AC8FF, true, this.dp);
            addHit(ID_P_OK, this.tmp2);
        } else {
            float bw = cw * 0.5f;
            this.tmp.set(cx - bw / 2.0f, by, cx + bw / 2.0f, by + btnH);
            Ui.button(c, this.tmp, this.popupOk, this.pressAnim[ID_P_OK], this.time, 0xFF1AC8FF, true, this.dp);
            addHit(ID_P_OK, this.tmp);
        }
        c.restoreToCount(layer);
        c.restore();
    }

    // ------------------------------------------------------------------ achievement toast

    private void checkAchievements() {
        ArrayList<Integer> fresh = Achievements.check();
        for (int i = 0; i < fresh.size(); i++) {
            this.toastQ.add(Achievements.NAMES[fresh.get(i)]);
        }
    }

    private void drawToast(Canvas c) {
        if (this.toastT <= 0.0f) {
            return;
        }
        float W = getWidth();
        float H = getHeight();
        float h = H * 0.062f;
        float w = W * 0.88f;
        float tin = 3.0f - this.toastT;
        float k = Ui.easeOutBack(Math.min(tin, 0.45f) / 0.45f) * Ui.clamp01(this.toastT / 0.35f);
        float y = Ui.lerp(-h * 1.6f, H * 0.018f, k);
        this.tmp.set((W - w) / 2.0f, y, (W + w) / 2.0f, y + h);
        Ui.panel(c, this.tmp, h * 0.5f, this.dp, 1.1f);
        Ui.star(c, this.tmp.left + h * 0.55f, this.tmp.centerY(), h * 0.26f, 0xFFFFD54F, 0xFFFFF3B0, tin * 2.0f, this.dp);
        Ui.text(c, "ACHIEVEMENT UNLOCKED", this.tmp.left + h * 1.05f, y + h * 0.4f, h * 0.22f, 0xFFFFD54F, Paint.Align.LEFT, 0.1f);
        Ui.text(c, this.toastText, this.tmp.left + h * 1.05f, y + h * 0.78f, h * 0.3f, 0xFFFFFFFF, Paint.Align.LEFT, 0.04f);
    }

    // ------------------------------------------------------------------ links, share, updates

    private void openUrl(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception ex) {
            Toast.makeText(getContext(), "Could not open the link", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareText(String text) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            Intent ch = Intent.createChooser(i, "Share");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
        } catch (Exception ex) {
            Toast.makeText(getContext(), "Could not open share", Toast.LENGTH_SHORT).show();
        }
    }

    private String shareAppText() {
        String s = "Try Flip Match, a glassy gravity-flip puzzle game made by Ayush Vaitage!";
        if (Updater.apkUrl.length() > 0) {
            s += " " + Updater.apkUrl;
        }
        return s;
    }

    private String shareScoreText() {
        String tail = " Can you beat me? Flip Match by Ayush Vaitage.";
        if (this.mode == 1 && this.levelWon) {
            return "I cleared Level " + (this.curLevel + 1) + " with " + this.starsEarned + " star(s) and scored " + this.score + " in Flip Match!" + tail;
        }
        if (this.mode == 1) {
            return "I'm trying Level " + (this.curLevel + 1) + " in Flip Match, scored " + this.score + " so far." + tail;
        }
        return "I scored " + this.score + " in Flip Match (Endless, " + Settings.DIFF_NAMES[Settings.difficulty] + ")!" + tail;
    }

    private void checkUpdates(boolean manual) {
        if (!Updater.configured()) {
            Toast.makeText(getContext(), "Update link is not set yet", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(getContext(), "Checking for updates...", Toast.LENGTH_SHORT).show();
        Updater.check(this, new Runnable() {
            @Override
            public void run() {
                if (!Updater.ok) {
                    Toast.makeText(getContext(), "Could not check, are you online?", Toast.LENGTH_SHORT).show();
                } else if (Updater.updateAvailable()) {
                    updShown = true;
                    showPopup(P_UPDATE, "UPDATE AVAILABLE", "Version " + Updater.versionName + " is ready.\n" + Updater.message, "UPDATE", "LATER");
                } else {
                    Toast.makeText(getContext(), "You are on the latest version", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void settingsButton(int id) {
        if (id == BTN_RESET) {
            tapReset();
        } else if (id == BTN_ABOUT) {
            gotoScreen(S_ABOUT);
        } else if (id == BTN_CHECK) {
            checkUpdates(true);
        } else if (id == BTN_CARD) {
            openUrl(INSTA_URL);
        }
    }

    // ------------------------------------------------------------------ HOME

    private void homeButton(Canvas c, int id, String label, float x, float y, float w, float h, int order, int tint, boolean primary) {
        float e = Ui.easeOutBack((this.screenAge - 0.25f - order * 0.09f) / 0.5f);
        float a = Ui.clamp01(e);
        if (a <= 0.0f) {
            return;
        }
        float slide = (1.0f - e) * this.dp * 46.0f;
        int layer = -1;
        if (a < 1.0f) {
            layer = c.saveLayerAlpha(x - this.dp * 12.0f, y - this.dp * 60.0f, x + w + this.dp * 12.0f, y + h + this.dp * 60.0f, (int) (255.0f * a));
        }
        c.save();
        c.translate(0.0f, slide);
        if (id == ID_PLAY) {
            float pu = 1.0f + 0.012f * (float) Math.sin(this.time * 2.4f);
            c.scale(pu, pu, x + w / 2.0f, y + h / 2.0f);
        }
        this.tmp.set(x, y, x + w, y + h);
        Ui.button(c, this.tmp, label, this.pressAnim[id], this.time, tint, primary, this.dp);
        c.restore();
        if (layer >= 0) {
            c.restoreToCount(layer);
        }
        if (e > 0.6f) {
            addHit(id, x, y, x + w, y + h);
        }
    }

    private void drawHome(Canvas c) {
        float W = getWidth();
        float H = getHeight();
        float age = this.screenAge;
        float t0 = this.time;
        drawFloaters(c, 1.0f);

        float le = Ui.easeOutBack(age / 0.75f);
        float lsize = Math.min(W * 0.46f, H * 0.21f);
        c.save();
        c.translate(0.0f, (1.0f - Math.min(1.0f, le)) * -H * 0.06f);
        Ui.logo(c, W / 2.0f, H * 0.205f, lsize * (0.55f + 0.45f * Math.min(1.1f, le)), t0, this.dp);
        c.restore();

        float ta = Ui.clamp01((age - 0.2f) / 0.5f);
        float tsz = W * 0.105f;
        Ui.textGlow(c, "FLIP MATCH", W / 2.0f, H * 0.388f, tsz, Ui.alpha(0xFF2EB8FF, ta), Ui.alpha(0xFF2EB8FF, ta * 0.9f), W * 0.03f, Paint.Align.CENTER, 0.1f);
        Ui.textShader(c, "FLIP MATCH", W / 2.0f, H * 0.388f, tsz, titleShimmer(), Paint.Align.CENTER, 0.1f, ta);
        Ui.text(c, "MATCH  \u2022  FLIP  \u2022  WIN", W / 2.0f, H * 0.416f, W * 0.032f, Ui.alpha(0xFFFFFFFF, 0.75f * ta), Paint.Align.CENTER, 0.3f);

        float bw = W * 0.74f;
        float bx = (W - bw) / 2.0f;
        homeButton(c, ID_PLAY, "PLAY", bx, H * 0.45f, bw, H * 0.075f, 0, 0xFF1AC8FF, true);
        homeButton(c, ID_ENDLESS, "ENDLESS", bx, H * 0.54f, bw, H * 0.063f, 1, 0xFFB06BFF, false);
        homeButton(c, ID_SETTINGS, "SETTINGS", bx, H * 0.617f, bw, H * 0.063f, 2, 0xFFFFFFFF, false);
        float sw2 = W * 0.355f;
        homeButton(c, ID_HOME_ACH, "ACHIEVEMENTS", W * 0.13f, H * 0.694f, sw2, H * 0.052f, 3, 0xFFFFFFFF, false);
        homeButton(c, ID_HOME_ABOUT, "ABOUT", W * 0.515f, H * 0.694f, sw2, H * 0.052f, 4, 0xFFE1306C, true);

        float se = Ui.easeOutCubic((age - 0.65f) / 0.5f);
        if (se > 0.0f) {
            c.save();
            c.translate(0.0f, (1.0f - se) * this.dp * 30.0f);
            int layer = -1;
            if (se < 1.0f) {
                layer = c.saveLayerAlpha(0.0f, H * 0.76f - this.dp * 40.0f, W, H * 0.85f + this.dp * 40.0f, (int) (255.0f * se));
            }
            float sw = W * 0.84f;
            float sx = (W - sw) / 2.0f;
            this.tmp.set(sx, H * 0.768f, sx + sw, H * 0.768f + H * 0.07f);
            Ui.panel(c, this.tmp, H * 0.02f, this.dp, 0.9f);
            float colW = sw / 3.0f;
            String[] lab = {"BEST (" + Settings.DIFF_NAMES[Settings.difficulty] + ")", "STARS", "NEXT LEVEL"};
            int nl = Settings.nextLevel();
            String[] val = {String.valueOf(Settings.bestFor(Settings.difficulty)), Settings.totalStars() + "/" + (Settings.LEVEL_COUNT * 3), nl < 0 ? "ALL DONE" : String.valueOf(nl + 1)};
            for (int i = 0; i < 3; i++) {
                float cx = sx + colW * (i + 0.5f);
                Ui.text(c, lab[i], cx, this.tmp.top + this.tmp.height() * 0.34f, W * 0.024f, 0xAAFFFFFF, Paint.Align.CENTER, 0.08f);
                Ui.text(c, val[i], cx, this.tmp.top + this.tmp.height() * 0.77f, W * 0.05f, i == 1 ? 0xFFFFD54F : 0xFFFFFFFF, Paint.Align.CENTER, 0.02f);
            }
            if (layer >= 0) {
                c.restoreToCount(layer);
            }
            c.restore();
        }

        float ce = Ui.clamp01((age - 0.9f) / 0.6f);
        if (ce > 0.0f) {
            Ui.text(c, "DEVELOPED & CREATED BY", W / 2.0f, H * 0.914f, W * 0.027f, Ui.alpha(0xFFFFFFFF, 0.7f * ce), Paint.Align.CENTER, 0.22f);
            float nsz = W * 0.066f;
            Ui.textGlow(c, "AYUSH VAITAGE", W / 2.0f, H * 0.947f, nsz, Ui.alpha(0xFFFF7AC8, ce), Ui.alpha(0xFFFF4DB8, 0.8f * ce), W * 0.025f, Paint.Align.CENTER, 0.08f);
            Ui.textShader(c, "AYUSH VAITAGE", W / 2.0f, H * 0.947f, nsz, titleShimmer(), Paint.Align.CENTER, 0.08f, ce);
            Ui.text(c, "v" + Updater.CURRENT_NAME, W / 2.0f, H * 0.975f, W * 0.025f, Ui.alpha(0xFFFFFFFF, 0.4f * ce), Paint.Align.CENTER, 0.1f);
        }
    }

    // ------------------------------------------------------------------ ABOUT

    private void drawAbout(Canvas c) {
        float W = getWidth();
        float H = getHeight();
        float age = this.screenAge;
        drawFloaters(c, 0.7f);
        drawHeader(c, "ABOUT", null);
        float le = Ui.easeOutBack(age / 0.7f);
        Ui.logo(c, W / 2.0f, H * 0.19f, Math.min(W * 0.38f, H * 0.17f) * (0.6f + 0.4f * Math.min(1.1f, le)), this.time, this.dp);
        float ta = Ui.clamp01((age - 0.2f) / 0.5f);
        Ui.textShader(c, "FLIP MATCH", W / 2.0f, H * 0.335f, W * 0.09f, titleShimmer(), Paint.Align.CENTER, 0.1f, ta);
        Ui.text(c, "VERSION " + Updater.CURRENT_NAME, W / 2.0f, H * 0.36f, W * 0.03f, Ui.alpha(0xFFFFFFFF, 0.7f * ta), Paint.Align.CENTER, 0.2f);

        float ce = Ui.easeOutCubic((age - 0.3f) / 0.5f);
        if (ce > 0.0f) {
            c.save();
            c.translate(0.0f, (1.0f - ce) * this.dp * 30.0f);
            int layer = c.saveLayerAlpha(0.0f, H * 0.38f - this.dp * 40.0f, W, H * 0.51f + this.dp * 40.0f, (int) (255.0f * ce));
            this.tmp.set(W * 0.08f, H * 0.385f, W * 0.92f, H * 0.5f);
            Ui.panel(c, this.tmp, W * 0.05f, this.dp, 1.0f);
            Ui.text(c, "DEVELOPED & CREATED BY", W / 2.0f, H * 0.425f, W * 0.028f, 0xBBFFFFFF, Paint.Align.CENTER, 0.2f);
            Ui.textGlow(c, "AYUSH VAITAGE", W / 2.0f, H * 0.472f, W * 0.07f, 0xFFFF7AC8, 0xCCFF4DB8, W * 0.025f, Paint.Align.CENTER, 0.08f);
            Ui.textShader(c, "AYUSH VAITAGE", W / 2.0f, H * 0.472f, W * 0.07f, titleShimmer(), Paint.Align.CENTER, 0.08f, 1.0f);
            c.restoreToCount(layer);
            c.restore();
        }
        float bw = W * 0.84f;
        float bx = (W - bw) / 2.0f;
        homeButton(c, ID_INSTA, "INSTAGRAM", bx, H * 0.53f, bw, H * 0.075f, 0, 0xFFE1306C, true);
        float ha = Ui.clamp01((age - 0.6f) / 0.4f);
        Ui.text(c, "@ayushvaitage", W / 2.0f, H * 0.633f, W * 0.036f, Ui.alpha(0xFFFF9EC4, ha), Paint.Align.CENTER, 0.06f);
        homeButton(c, ID_SHARE_APP, "SHARE THE GAME", bx, H * 0.665f, bw, H * 0.063f, 1, 0xFFFFFFFF, false);
        homeButton(c, ID_UPDATE, "CHECK FOR UPDATES", bx, H * 0.745f, bw, H * 0.063f, 2, 0xFFFFFFFF, false);
        Ui.text(c, "Thank you for playing!", W / 2.0f, H * 0.88f, W * 0.036f, Ui.alpha(0xFFFFFFFF, 0.65f * ha), Paint.Align.CENTER, 0.06f);
    }

    // ------------------------------------------------------------------ ACHIEVEMENTS

    private void drawAch(Canvas c) {
        float W = getWidth();
        float H = getHeight();
        drawFloaters(c, 0.6f);
        drawHeader(c, "ACHIEVEMENTS", Achievements.doneCount() + "/" + Achievements.COUNT);
        float mx = W * 0.045f;
        float cardH = H * 0.073f;
        float gap = H * 0.009f;
        float top0 = H * 0.128f;
        for (int i = 0; i < Achievements.COUNT; i++) {
            float e = Ui.easeOutBack((this.screenAge - 0.06f - i * 0.045f) / 0.4f);
            if (e <= 0.0f) {
                continue;
            }
            float y = top0 + i * (cardH + gap);
            boolean done = Settings.ach[i];
            int target = Achievements.TARGET[i];
            int cur = Math.min(Achievements.progress(i), target);
            c.save();
            float s2 = 0.85f + 0.15f * Math.min(1.1f, e);
            c.scale(s2, s2, W / 2.0f, y + cardH / 2.0f);
            int layer = -1;
            if (e < 1.0f) {
                layer = c.saveLayerAlpha(0.0f, y - this.dp * 20.0f, W, y + cardH + this.dp * 20.0f, (int) (255.0f * Ui.clamp01(e)));
            }
            this.tmp.set(mx, y, W - mx, y + cardH);
            Ui.panel(c, this.tmp, cardH * 0.28f, this.dp, done ? 1.1f : 0.75f);
            float ix = mx + cardH * 0.55f;
            float iy = y + cardH / 2.0f;
            if (done) {
                Ui.glow(c, ix, iy, cardH * 0.9f, 0x44FFD54F);
                Ui.star(c, ix, iy, cardH * 0.27f, 0xFFFFD54F, 0xFFFFF3B0, 0.0f, this.dp);
            } else {
                Ui.lock(c, ix, iy, cardH * 0.34f, 0x88FFFFFF, this.dp);
            }
            float tx = mx + cardH * 1.1f;
            float rx = W - mx - cardH * 0.3f;
            Ui.text(c, Achievements.NAMES[i], tx, y + cardH * 0.36f, cardH * 0.24f, done ? 0xFFFFD54F : 0xFFFFFFFF, Paint.Align.LEFT, 0.06f);
            Ui.text(c, Achievements.DESC[i], tx, y + cardH * 0.6f, cardH * 0.17f, 0xBBFFFFFF, Paint.Align.LEFT, 0.01f);
            Ui.text(c, done ? "DONE" : cur + "/" + target, rx, y + cardH * 0.38f, cardH * 0.22f, done ? 0xFF4DFFB0 : 0xFF8FD8FF, Paint.Align.RIGHT, 0.04f);
            if (!done) {
                this.tmp.set(tx, y + cardH * 0.74f, rx, y + cardH * 0.84f);
                Ui.liquidBar(c, this.tmp, ((float) cur) / target, this.time, 0xFF2EE6FF, 0xFF3D7BFF, this.dp);
            }
            if (layer >= 0) {
                c.restoreToCount(layer);
            }
            c.restore();
        }
    }

    // ------------------------------------------------------------------ game over / level complete overlay

    private final void drawOver(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float p = Math.min(1.0f, this.overT / 0.5f);
        this.plain.setShader(null);
        this.plain.setColor(withAlpha(-16777216, (int) (170 * p)));
        canvas.drawRect(0.0f, 0.0f, w, h, this.plain);
        Glass g = this.overGlass;
        if (g == null) {
            return;
        }
        RectF rc = g.getRect();
        float rh = rc.height();
        float s = easeOutBack(p);
        canvas.save();
        canvas.translate(rc.centerX(), rc.centerY());
        canvas.scale((s * 0.4f) + 0.6f, (0.4f * s) + 0.6f);
        canvas.translate(-rc.centerX(), -rc.centerY());
        drawGlass(canvas, g);
        String title;
        int tcol;
        float tsz = w * 0.1f;
        if (this.mode == 1) {
            title = this.levelWon ? "LEVEL COMPLETE!" : "LEVEL FAILED";
            tcol = this.levelWon ? -10929 : -38037;
            tsz = w * (this.levelWon ? 0.074f : 0.09f);
        } else {
            title = this.newBest ? "NEW BEST!" : "GAME OVER";
            tcol = this.newBest ? -10929 : -1;
        }
        drawText$default(this, canvas, title, w / 2.0f, rc.top + rh * 0.13f, tsz, tcol, null, 64, null);
        float labelY;
        float scoreY;
        float extraY;
        if (this.mode == 1) {
            float sr = w * 0.058f;
            for (int i = 0; i < 3; i++) {
                float pop = easeOutBack((this.overT - 0.35f - i * 0.28f) / 0.4f);
                float sx = w / 2.0f + (i - 1) * w * 0.19f;
                float sy = rc.top + rh * 0.27f;
                boolean got = this.levelWon && i < this.starsEarned;
                if (pop > 0.0f) {
                    if (got && i >= this.starsShown && this.overT > 0.35f + i * 0.28f + 0.05f) {
                        this.starsShown = i + 1;
                        this.sfx.star();
                        burst(sx, sy, i % this.types);
                    }
                    if (got) {
                        Ui.glow(canvas, sx, sy, sr * 2.1f * Math.min(1.0f, pop), 0x66FFD54F);
                    }
                    Ui.star(canvas, sx, sy, sr * Math.max(0.01f, pop), got ? 0xFFFFD54F : 0x33FFFFFF, got ? 0xFFFFF3B0 : 0x55FFFFFF, (1.0f - Math.min(1.0f, pop)) * 0.6f, this.dp);
                }
            }
            labelY = rc.top + rh * 0.45f;
            scoreY = rc.top + rh * 0.58f;
            extraY = rc.top + rh * 0.645f;
        } else {
            labelY = rc.top + rh * 0.33f;
            scoreY = rc.top + rh * 0.5f;
            extraY = rc.top + rh * 0.59f;
        }
        drawText$default(this, canvas, "SCORE", w / 2.0f, labelY, 0.038f * w, -1426063361, null, 64, null);
        drawText$default(this, canvas, String.valueOf(this.score), w / 2.0f, scoreY, w * 0.11f, -1, null, 64, null);
        if (this.mode == 1) {
            drawText$default(this, canvas, "GOAL " + this.levelTarget, w / 2.0f, extraY, 0.034f * w, -1426063361, null, 64, null);
        } else {
            drawText$default(this, canvas, "BEST " + this.best, w / 2.0f, extraY, 0.04f * w, -10929, null, 64, null);
        }
        String left;
        String right;
        if (this.mode == 1) {
            if (this.levelWon) {
                left = "REPLAY";
                right = this.curLevel < Settings.LEVEL_COUNT - 1 ? "NEXT" : "LEVELS";
            } else {
                left = "LEVELS";
                right = "RETRY";
            }
        } else {
            left = "MENU";
            right = "AGAIN";
        }
        float bh = rh * 0.12f;
        float by = rc.bottom - rh * 0.05f - bh;
        float bw = rc.width() * 0.4f;
        float be = Ui.clamp01((this.overT - 0.45f) / 0.3f);
        if (be > 0.0f) {
            float shw = rc.width() * 0.34f;
            float sh = rh * 0.085f;
            this.tmp3.set(rc.centerX() - shw / 2.0f, rc.top + rh * 0.7f, rc.centerX() + shw / 2.0f, rc.top + rh * 0.7f + sh);
            Ui.button(canvas, this.tmp3, "SHARE", this.pressAnim[ID_O_SHARE], this.time, 0xFFFFFFFF, false, this.dp);
            addHit(ID_O_SHARE, this.tmp3);
            this.tmp.set(rc.left + rc.width() * 0.07f, by, rc.left + rc.width() * 0.07f + bw, by + bh);
            Ui.button(canvas, this.tmp, left, this.pressAnim[ID_O_LEFT], this.time, 0xFFFFFFFF, false, this.dp);
            addHit(ID_O_LEFT, this.tmp);
            this.tmp2.set(rc.right - rc.width() * 0.07f - bw, by, rc.right - rc.width() * 0.07f, by + bh);
            Ui.button(canvas, this.tmp2, right, this.pressAnim[ID_O_RIGHT], this.time, 0xFF1AC8FF, true, this.dp);
            addHit(ID_O_RIGHT, this.tmp2);
        }
        canvas.restore();
    }
}
