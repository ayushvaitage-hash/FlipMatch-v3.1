package com.flipmatch.game;

import android.graphics.RectF;
import android.graphics.Shader;
final class Glass {
    private final Shader edge;
    private final Shader fill;
    private final float radius;
    private final RectF rect;

    public Glass(RectF rect, float radius, Shader fill, Shader edge) {
        this.rect = rect;
        this.radius = radius;
        this.fill = fill;
        this.edge = edge;
    }

    public final Shader getEdge() {
        return this.edge;
    }

    public final Shader getFill() {
        return this.fill;
    }

    public final float getRadius() {
        return this.radius;
    }

    public final RectF getRect() {
        return this.rect;
    }
}
