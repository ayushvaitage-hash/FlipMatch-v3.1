package com.flipmatch.game;

/** Level + difficulty tuning. Level index is 0-based, difficulty 0=EASY 1=MEDIUM 2=HARD 3=HARDEST. */
final class Levels {
    private Levels() {}

    private static final float[] TARGET_SCALE = {0.8f, 1.0f, 1.25f, 1.5f};
    private static final int[] MOVE_DELTA = {6, 0, -3, -5};
    private static final int[] FLIP_DELTA = {1, 0, -1, -2};
    private static final float[] HINT_DELAY = {2.5f, 4f, 6f, 0f};
    private static final int[] ENDLESS_MOVES = {40, 30, 24, 18};
    private static final int[] ENDLESS_FLIP = {7, 5, 4, 3};
    private static final int[] ENDLESS_TYPES = {5, 6, 6, 6};

    static int target(int level, int diff) {
        float base = 300f + 150f * level;
        int t = Math.round(base * TARGET_SCALE[diff] / 50f) * 50;
        return Math.max(150, t);
    }

    static int moves(int level, int diff) {
        return Math.max(12, 20 + level / 3 + MOVE_DELTA[diff]);
    }

    static int types(int level, int diff) {
        int t = level < 4 ? 5 : 6;
        if (diff == 0 && level < 12) {
            t = 5;
        }
        return t;
    }

    /** 0 means gravity never flips on this level. */
    static int flipEvery(int level, int diff) {
        int base;
        if (level < 3) {
            base = 0;
        } else if (level < 9) {
            base = 7;
        } else if (level < 15) {
            base = 6;
        } else if (level < 22) {
            base = 5;
        } else {
            base = 4;
        }
        if (base == 0) {
            return diff >= 2 ? (diff == 2 ? 8 : 7) : 0;
        }
        return Math.max(3, base + FLIP_DELTA[diff]);
    }

    static float hintDelay(int diff) {
        return HINT_DELAY[diff];
    }

    static int endlessMoves(int diff) {
        return ENDLESS_MOVES[diff];
    }

    static int endlessFlip(int diff) {
        return ENDLESS_FLIP[diff];
    }

    static int endlessTypes(int diff) {
        return ENDLESS_TYPES[diff];
    }

    static String describe(int diff) {
        switch (diff) {
            case 0:
                return "More moves, 5 colours, slower flips, quick hints";
            case 2:
                return "Fewer moves, faster flips, slow hints";
            case 3:
                return "Tiny move budget, flips every 3, no hints";
            default:
                return "The classic Flip Match experience";
        }
    }
}
