package com.flipmatch.game;
final class Particle {
    private final int color;
    private final int kind;
    private float life;
    private final float maxLife;
    private final float size;
    private float vx;
    private float vy;
    private float x;
    private float y;

    public Particle(float x, float y, float vx, float vy, float life, float maxLife, float size, int color, int kind) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.life = life;
        this.maxLife = maxLife;
        this.size = size;
        this.color = color;
        this.kind = kind;
    }

    public final float getVx() {
        return this.vx;
    }

    public final float getVy() {
        return this.vy;
    }

    public final float getX() {
        return this.x;
    }

    public final float getY() {
        return this.y;
    }

    public final void setVx(float f) {
        this.vx = f;
    }

    public final void setVy(float f) {
        this.vy = f;
    }

    public final void setX(float f) {
        this.x = f;
    }

    public final void setY(float f) {
        this.y = f;
    }

    public final int getColor() {
        return this.color;
    }

    public final int getKind() {
        return this.kind;
    }

    public final float getLife() {
        return this.life;
    }

    public final float getMaxLife() {
        return this.maxLife;
    }

    public final float getSize() {
        return this.size;
    }

    public final void setLife(float f) {
        this.life = f;
    }
}
