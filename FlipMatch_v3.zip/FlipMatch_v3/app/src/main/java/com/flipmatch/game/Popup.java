package com.flipmatch.game;
final class Popup {
    private final int color;
    private float life;
    private final String text;
    private final float x;
    private final float y;

    public Popup(String text, float x, float y, float life, int color) {
        this.text = text;
        this.x = x;
        this.y = y;
        this.life = life;
        this.color = color;
    }

    public final int getColor() {
        return this.color;
    }

    public final float getLife() {
        return this.life;
    }

    public final String getText() {
        return this.text;
    }

    public final float getX() {
        return this.x;
    }

    public final float getY() {
        return this.y;
    }

    public final void setLife(float f) {
        this.life = f;
    }
}
