package com.flipmatch.game;

/** Tiny stand-in for kotlin.ranges.RangesKt so the old decompiled calls keep working in pure Java. */
final class RangesKt {
    private RangesKt() {}
    static int coerceIn(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
    static float coerceIn(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
}
