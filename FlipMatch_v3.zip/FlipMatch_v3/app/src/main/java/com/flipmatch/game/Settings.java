package com.flipmatch.game;

import android.content.SharedPreferences;

/** All player options + saved progress. Everything lives in the same "flipmatch" prefs file as the old "best" score. */
final class Settings {
    private Settings() {}

    static final String[] DIFF_NAMES = {"EASY", "MEDIUM", "HARD", "HARDEST"};
    static final String[] THEME_NAMES = {"AURORA", "SUNSET", "OCEAN", "NEON"};
    static final int LEVEL_COUNT = 30;

    static int difficulty = 1;
    static boolean sound = true;
    static float volume = 0.8f;      // 0..1
    static boolean haptics = true;
    static boolean shake = true;
    static float particles = 1f;     // 0..1
    static float speed = 1f;         // 0.6 .. 1.6
    static boolean hints = true;
    static boolean gravityFlip = true;
    static boolean bgFx = true;
    static int theme = 0;
    static final int[] stars = new int[LEVEL_COUNT];

    // counters / achievements / daily reward / announcements
    static int cntFlips;
    static int cntGames;
    static int bestCombo;
    static int maxEndless;
    static int streak;
    static int maxStreak;
    static int bonusMoves;
    static int seenAnn;
    static long lastClaimDay = -1;
    static boolean hardWin;
    static final boolean[] ach = new boolean[Achievements.COUNT];

    private static SharedPreferences prefs;

    static void load(SharedPreferences p) {
        prefs = p;
        difficulty = clampI(p.getInt("difficulty", 1), 0, 3);
        sound = p.getBoolean("sound", true);
        volume = clampF(p.getFloat("volume", 0.8f), 0f, 1f);
        haptics = p.getBoolean("haptics", true);
        shake = p.getBoolean("shake", true);
        particles = clampF(p.getFloat("particles", 1f), 0f, 1f);
        speed = clampF(p.getFloat("speed", 1f), 0.6f, 1.6f);
        hints = p.getBoolean("hints", true);
        gravityFlip = p.getBoolean("gravityFlip", true);
        bgFx = p.getBoolean("bgFx", true);
        theme = clampI(p.getInt("theme", 0), 0, 3);
        for (int i = 0; i < LEVEL_COUNT; i++) {
            stars[i] = clampI(p.getInt("stars_" + i, 0), 0, 3);
        }
        cntFlips = p.getInt("cntFlips", 0);
        cntGames = p.getInt("cntGames", 0);
        bestCombo = p.getInt("bestCombo", 0);
        maxEndless = p.getInt("maxEndless", 0);
        streak = p.getInt("streak", 0);
        maxStreak = p.getInt("maxStreak", 0);
        bonusMoves = p.getInt("bonusMoves", 0);
        seenAnn = p.getInt("seenAnn", 0);
        lastClaimDay = p.getLong("lastClaimDay", -1L);
        hardWin = p.getBoolean("hardWin", false);
        for (int i = 0; i < Achievements.COUNT; i++) {
            ach[i] = p.getBoolean("ach_" + i, false);
        }
        // old versions only stored one "best"; treat it as the MEDIUM best
        if (!p.contains("best_d1") && p.contains("best")) {
            p.edit().putInt("best_d1", p.getInt("best", 0)).apply();
        }
    }

    static void save() {
        if (prefs == null) {
            return;
        }
        SharedPreferences.Editor e = prefs.edit();
        e.putInt("difficulty", difficulty);
        e.putBoolean("sound", sound);
        e.putFloat("volume", volume);
        e.putBoolean("haptics", haptics);
        e.putBoolean("shake", shake);
        e.putFloat("particles", particles);
        e.putFloat("speed", speed);
        e.putBoolean("hints", hints);
        e.putBoolean("gravityFlip", gravityFlip);
        e.putBoolean("bgFx", bgFx);
        e.putInt("theme", theme);
        for (int i = 0; i < LEVEL_COUNT; i++) {
            e.putInt("stars_" + i, stars[i]);
        }
        e.putInt("cntFlips", cntFlips);
        e.putInt("cntGames", cntGames);
        e.putInt("bestCombo", bestCombo);
        e.putInt("maxEndless", maxEndless);
        e.putInt("streak", streak);
        e.putInt("maxStreak", maxStreak);
        e.putInt("bonusMoves", bonusMoves);
        e.putInt("seenAnn", seenAnn);
        e.putLong("lastClaimDay", lastClaimDay);
        e.putBoolean("hardWin", hardWin);
        for (int i = 0; i < Achievements.COUNT; i++) {
            e.putBoolean("ach_" + i, ach[i]);
        }
        e.apply();
    }

    static long today() {
        long now = System.currentTimeMillis();
        return (now + java.util.TimeZone.getDefault().getOffset(now)) / 86400000L;
    }

    static boolean dailyAvailable() {
        return lastClaimDay != today();
    }

    /** Claims today's reward and returns the number of bonus moves granted. */
    static int claimDaily() {
        long day = today();
        streak = (lastClaimDay == day - 1) ? streak + 1 : 1;
        if (streak > maxStreak) {
            maxStreak = streak;
        }
        int reward = Math.min(8, 2 + streak);
        bonusMoves += reward;
        lastClaimDay = day;
        save();
        return reward;
    }

    static int bestFor(int diff) {
        return prefs == null ? 0 : prefs.getInt("best_d" + diff, 0);
    }

    static void setBest(int diff, int value) {
        if (prefs != null) {
            prefs.edit().putInt("best_d" + diff, value).apply();
        }
    }

    static int totalStars() {
        int t = 0;
        for (int i = 0; i < LEVEL_COUNT; i++) {
            t += stars[i];
        }
        return t;
    }

    static boolean unlocked(int level) {
        return level <= 0 || stars[level - 1] > 0;
    }

    /** First level that is unlocked but not yet beaten, or -1 when everything is done. */
    static int nextLevel() {
        for (int i = 0; i < LEVEL_COUNT; i++) {
            if (stars[i] == 0) {
                return i;
            }
        }
        return -1;
    }

    static void resetProgress() {
        for (int i = 0; i < LEVEL_COUNT; i++) {
            stars[i] = 0;
        }
        cntFlips = 0;
        cntGames = 0;
        bestCombo = 0;
        maxEndless = 0;
        streak = 0;
        maxStreak = 0;
        hardWin = false;
        for (int i = 0; i < Achievements.COUNT; i++) {
            ach[i] = false;
        }
        if (prefs != null) {
            SharedPreferences.Editor e = prefs.edit();
            e.remove("best");
            for (int d = 0; d < 4; d++) {
                e.remove("best_d" + d);
            }
            e.apply();
        }
        save();
    }

    private static int clampI(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static float clampF(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
