package com.flipmatch.game;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Soft, synthesized sound effects: warm bell / marimba tones on a pentatonic scale,
 * airy whooshes and gentle pops. Everything is generated at start-up, no audio files needed.
 */
final class SoundFx {
    private static final int RATE = 44100;
    private static final float[] SCALE = {523.25f, 587.33f, 659.25f, 783.99f, 880.00f, 1046.50f, 1174.66f, 1318.51f};

    private final Random rnd = new Random(11);
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private boolean enabled = true;
    private float volume = 0.8f;

    private final short[] tapS;
    private final short[] swapS;
    private final short[] badS;
    private final short[] landS;
    private final short[] flipS;
    private final short[] overS;
    private final short[] winS;
    private final short[] starS;
    private final short[] rewardS;
    private final short[] notifyS;
    private final short[] whooshS;
    private final short[][] matchS = new short[8][];

    SoundFx() {
        // soft bubble pop for buttons
        tapS = finish(sweep(540f, 820f, 75, 0.34f, 38f), 0.55f);
        // quick airy slide for swapping tiles
        swapS = finish(sweep(330f, 560f, 95, 0.26f, 20f), 0.5f);
        // gentle low "bonk" for an invalid move
        badS = finish(mixAll(sweep(230f, 170f, 190, 0.4f, 13f), sweep(115f, 85f, 190, 0.25f, 13f)), 0.45f);
        // tile landing: soft thud
        landS = finish(mixAll(sweep(150f, 62f, 120, 0.55f, 26f), noiseBurst(40, 0.12f, 0.18f)), 0.4f);
        // gravity flip: rising swoosh with a sine glide
        flipS = finish(flipSound(), 0.55f);
        whooshS = finish(airy(300, 0.5f), 0.6f);
        // matches: bell + soft fifth, climbing the pentatonic scale with the combo
        for (int i = 0; i < 8; i++) {
            float f = SCALE[i];
            float[] a = note(f, 520, 0.5f, 0.7f, 6.5f);
            float[] b = note(f * 1.5f, 380, 0.2f, 0.5f, 9f);
            float[] c = new float[a.length];
            addAt(c, a, 0);
            addAt(c, b, ms(45));
            matchS[i] = finish(echo(c, 110, 0.28f, 3), 0.6f);
        }
        // one bright bell
        starS = finish(echo(note(1318.51f, 700, 0.5f, 0.8f, 5f), 120, 0.3f, 3), 0.6f);
        // game over: slow, soft, falling
        overS = finish(echo(seq(new float[][]{
                note(440.00f, 330, 0.42f, 0.4f, 5.5f),
                note(349.23f, 330, 0.42f, 0.4f, 5.5f),
                note(293.66f, 700, 0.45f, 0.35f, 4.2f)}, new int[]{0, 240, 480}), 140, 0.3f, 3), 0.55f);
        // level complete: rising major arpeggio with a long shimmer
        winS = finish(echo(seq(new float[][]{
                note(523.25f, 380, 0.45f, 0.7f, 5.5f),
                note(659.25f, 380, 0.45f, 0.7f, 5.5f),
                note(783.99f, 380, 0.45f, 0.7f, 5.5f),
                note(1046.50f, 600, 0.5f, 0.8f, 4.5f),
                note(1318.51f, 900, 0.5f, 0.8f, 3.5f)}, new int[]{0, 120, 240, 360, 520}), 150, 0.32f, 4), 0.6f);
        // daily reward / achievement sparkle
        rewardS = finish(echo(seq(new float[][]{
                note(880.00f, 300, 0.4f, 0.8f, 7f),
                note(1174.66f, 300, 0.4f, 0.8f, 7f),
                note(1567.98f, 300, 0.4f, 0.8f, 7f),
                note(2093.00f, 600, 0.38f, 0.8f, 5f)}, new int[]{0, 70, 140, 210}), 110, 0.3f, 3), 0.55f);
        // two soft notes for notifications
        notifyS = finish(echo(seq(new float[][]{
                note(783.99f, 320, 0.42f, 0.6f, 6.5f),
                note(1046.50f, 520, 0.42f, 0.6f, 5.5f)}, new int[]{0, 130}), 120, 0.28f, 3), 0.55f);
    }

    // ------------------------------------------------------------------ public API

    public final boolean getEnabled() {
        return this.enabled;
    }

    public final void setEnabled(boolean e) {
        this.enabled = e;
    }

    public final float getVolume() {
        return this.volume;
    }

    public final void setVolume(float v) {
        this.volume = v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
    }

    public final void tap() {
        play(this.tapS, 1.0f);
    }

    public final void swap() {
        play(this.swapS, 1.0f);
    }

    public final void bad() {
        play(this.badS, 1.0f);
    }

    public final void land() {
        play(this.landS, 0.9f);
    }

    public final void flip() {
        play(this.flipS, 1.0f);
    }

    public final void over() {
        play(this.overS, 1.0f);
    }

    public final void win() {
        play(this.winS, 1.0f);
    }

    public final void star() {
        play(this.starS, 0.9f);
    }

    public final void reward() {
        play(this.rewardS, 1.0f);
    }

    public final void notifyChime() {
        play(this.notifyS, 1.0f);
    }

    public final void whoosh() {
        play(this.whooshS, 0.55f);
    }

    public final void match(int combo) {
        int idx = combo - 1;
        if (idx < 0) {
            idx = 0;
        }
        if (idx > 7) {
            idx = 7;
        }
        play(this.matchS[idx], 1.0f);
    }

    // ------------------------------------------------------------------ playback

    private void play(final short[] data, final float gain) {
        if (!this.enabled || this.volume <= 0.001f) {
            return;
        }
        final float vol = this.volume * gain;
        this.pool.execute(new Runnable() {
            @Override
            public void run() {
                SoundFx.this.playNow(data, vol);
            }
        });
    }

    private void playNow(short[] data, float vol) {
        try {
            AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(14).setContentType(4).build())
                    .setAudioFormat(new AudioFormat.Builder().setEncoding(2).setSampleRate(RATE).setChannelMask(4).build())
                    .setBufferSizeInBytes(data.length * 2)
                    .setTransferMode(0)
                    .build();
            track.setVolume(vol > 1.0f ? 1.0f : vol);
            track.write(data, 0, data.length);
            track.play();
            Thread.sleep(((((long) data.length) * 1000L) / RATE) + 80L);
            track.release();
        } catch (Exception e) {
            // audio is optional, never crash the game over it
        }
    }

    // ------------------------------------------------------------------ synthesis

    private static int ms(int millis) {
        return RATE * millis / 1000;
    }

    /** Warm bell / marimba note: fundamental plus a few quickly-fading overtones and a tiny detuned shimmer. */
    private float[] note(float f, int millis, float vol, float bright, float decay) {
        int n = ms(millis);
        float[] out = new float[n];
        int atk = ms(6);
        for (int i = 0; i < n; i++) {
            float t = i / (float) RATE;
            float env = (i < atk ? i / (float) atk : 1.0f) * (float) Math.exp(-decay * t);
            double ph = 2.0 * Math.PI * f * t;
            float s = (float) Math.sin(ph)
                    + 0.30f * (float) Math.sin(f * 1.003f * 2.0 * Math.PI * t)
                    + 0.32f * bright * (float) Math.sin(2.0 * ph) * (float) Math.exp(-decay * 0.9f * t)
                    + 0.14f * bright * (float) Math.sin(3.0 * ph) * (float) Math.exp(-decay * 1.6f * t)
                    + 0.07f * bright * (float) Math.sin(4.2 * ph) * (float) Math.exp(-decay * 2.4f * t);
            out[i] = s * env * vol * 0.7f;
        }
        return out;
    }

    /** Sine glide from f0 to f1 with a smooth attack and exponential decay. */
    private float[] sweep(float f0, float f1, int millis, float vol, float decay) {
        int n = ms(millis);
        float[] out = new float[n];
        double ph = 0.0;
        int atk = Math.max(1, ms(4));
        for (int i = 0; i < n; i++) {
            float p = i / (float) n;
            float f = f0 + (f1 - f0) * p;
            ph += 2.0 * Math.PI * f / RATE;
            float env = (i < atk ? i / (float) atk : 1.0f) * (float) Math.exp(-decay * (i / (float) RATE));
            out[i] = (float) Math.sin(ph) * env * vol;
        }
        return out;
    }

    private float[] noiseBurst(int millis, float vol, float lp) {
        int n = ms(millis);
        float[] out = new float[n];
        float y = 0f;
        for (int i = 0; i < n; i++) {
            float x = (rnd.nextFloat() * 2f - 1f);
            y += lp * (x - y);
            float env = (float) Math.exp(-40f * (i / (float) RATE));
            out[i] = y * env * vol;
        }
        return out;
    }

    /** Airy swoosh: low-passed noise whose cut-off rises then falls under a smooth bell-shaped envelope. */
    private float[] airy(int millis, float vol) {
        int n = ms(millis);
        float[] out = new float[n];
        float y = 0f;
        float z = 0f;
        for (int i = 0; i < n; i++) {
            float p = i / (float) n;
            float env = (float) Math.sin(Math.PI * p);
            env *= env;
            float a = 0.03f + 0.22f * (float) Math.sin(Math.PI * p);
            float x = (rnd.nextFloat() * 2f - 1f);
            y += a * (x - y);
            z += a * (y - z);
            out[i] = z * env * vol * 3.2f;
        }
        return out;
    }

    private float[] flipSound() {
        float[] w = airy(620, 0.55f);
        float[] g = new float[w.length];
        double ph = 0.0;
        for (int i = 0; i < g.length; i++) {
            float p = i / (float) g.length;
            float f = 170f + 520f * p * p;
            ph += 2.0 * Math.PI * f / RATE;
            float env = (float) Math.sin(Math.PI * p);
            g[i] = (float) Math.sin(ph) * env * env * 0.16f;
        }
        return mixAll(w, g);
    }

    private static float[] mixAll(float[]... parts) {
        int n = 0;
        for (float[] p : parts) {
            n = Math.max(n, p.length);
        }
        float[] out = new float[n];
        for (float[] p : parts) {
            addAt(out, p, 0);
        }
        return out;
    }

    private static void addAt(float[] dst, float[] src, int offset) {
        for (int i = 0; i < src.length; i++) {
            int j = i + offset;
            if (j >= 0 && j < dst.length) {
                dst[j] += src[i];
            }
        }
    }

    /** Places each part at its start time (ms). */
    private static float[] seq(float[][] parts, int[] startMs) {
        int n = 0;
        for (int i = 0; i < parts.length; i++) {
            n = Math.max(n, ms(startMs[i]) + parts[i].length);
        }
        float[] out = new float[n];
        for (int i = 0; i < parts.length; i++) {
            addAt(out, parts[i], ms(startMs[i]));
        }
        return out;
    }

    /** Simple feedback echo that gives chimes a soft room tail. */
    private static float[] echo(float[] in, int delayMs, float fb, int taps) {
        int d = ms(delayMs);
        float[] out = new float[in.length + d * taps];
        float g = 1.0f;
        for (int k = 0; k <= taps; k++) {
            addScaled(out, in, d * k, g);
            g *= fb;
        }
        return out;
    }

    private static void addScaled(float[] dst, float[] src, int offset, float g) {
        for (int i = 0; i < src.length; i++) {
            int j = i + offset;
            if (j < dst.length) {
                dst[j] += src[i] * g;
            }
        }
    }

    /** Soft low-pass, soft clip, short fade-out, then convert to 16-bit. */
    private static short[] finish(float[] x, float level) {
        int n = x.length;
        short[] out = new short[n];
        float y = 0f;
        int fade = Math.min(n, ms(25));
        for (int i = 0; i < n; i++) {
            y += 0.55f * (x[i] - y);
            float v = (float) Math.tanh(y * 1.15f) * level;
            if (i > n - fade) {
                v *= (n - i) / (float) fade;
            }
            out[i] = (short) (v * 30000f);
        }
        return out;
    }
}
