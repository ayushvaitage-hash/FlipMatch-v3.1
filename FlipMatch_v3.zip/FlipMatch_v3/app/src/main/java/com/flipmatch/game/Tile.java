package com.flipmatch.game;
final class Tile {
    private boolean bounce;
    private float c;
    private float delay;
    private float fromC;
    private float fromR;
    private boolean moving;
    private float r;
    private float toC;
    private float toR;
    private int type;
    private float scale = 1.0f;
    private float alpha = 1.0f;
    private float dur = 0.2f;

    public Tile(int type, float r, float c) {
        this.type = type;
        this.r = r;
        this.c = c;
        this.fromR = this.r;
        this.fromC = this.c;
        this.toR = this.r;
        this.toC = this.c;
    }

    public final float getC() {
        return this.c;
    }

    public final float getR() {
        return this.r;
    }

    public final int getType() {
        return this.type;
    }

    public final void setC(float f) {
        this.c = f;
    }

    public final void setR(float f) {
        this.r = f;
    }

    public final void setType(int i) {
        this.type = i;
    }

    public final float getScale() {
        return this.scale;
    }

    public final void setScale(float f) {
        this.scale = f;
    }

    public final float getAlpha() {
        return this.alpha;
    }

    public final void setAlpha(float f) {
        this.alpha = f;
    }

    public final float getFromR() {
        return this.fromR;
    }

    public final void setFromR(float f) {
        this.fromR = f;
    }

    public final float getFromC() {
        return this.fromC;
    }

    public final void setFromC(float f) {
        this.fromC = f;
    }

    public final float getToR() {
        return this.toR;
    }

    public final void setToR(float f) {
        this.toR = f;
    }

    public final float getToC() {
        return this.toC;
    }

    public final void setToC(float f) {
        this.toC = f;
    }

    public final float getDelay() {
        return this.delay;
    }

    public final void setDelay(float f) {
        this.delay = f;
    }

    public final float getDur() {
        return this.dur;
    }

    public final void setDur(float f) {
        this.dur = f;
    }

    public final boolean getMoving() {
        return this.moving;
    }

    public final void setMoving(boolean z) {
        this.moving = z;
    }

    public final boolean getBounce() {
        return this.bounce;
    }

    public final void setBounce(boolean z) {
        this.bounce = z;
    }
}
