package com.flipmatch.game;

import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

/** Reusable "liquid glass" widgets drawn straight onto the canvas. Single UI thread only (shared scratch objects). */
final class Ui {
    private Ui() {}

    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint TP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint ADD = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Path PA = new Path();
    private static final Path PB = new Path();
    private static final RectF R1 = new RectF();
    private static final RectF R2 = new RectF();

    static {
        TP.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        ADD.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
    }

    // ------------------------------------------------------------------ math / colour helpers

    static float clamp01(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    static float easeOutCubic(float x) {
        float p = 1f - clamp01(x);
        return 1f - p * p * p;
    }

    static float easeInOut(float x) {
        x = clamp01(x);
        return x < 0.5f ? 4f * x * x * x : 1f - (float) Math.pow(-2f * x + 2f, 3) / 2f;
    }

    /** Glossy glass band that sweeps across the screen during page changes (p = 0..1). */
    static void sweep(Canvas c, float w, float h, float p) {
        float a = (float) Math.sin(Math.PI * clamp01(p));
        float x = lerp(-w * 0.3f, w * 1.3f, clamp01(p));
        float bw = w * 0.22f;
        PA.reset();
        PA.moveTo(x, 0f);
        PA.lineTo(x + bw, 0f);
        PA.lineTo(x + bw - h * 0.12f, h);
        PA.lineTo(x - h * 0.12f, h);
        PA.close();
        P.setStyle(Paint.Style.FILL);
        P.setShader(new LinearGradient(x, 0f, x + bw, 0f,
                new int[]{0x00FFFFFF, alpha(0x34FFFFFF, a), 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        c.drawPath(PA, P);
        P.setShader(null);
    }

    static float easeOutBack(float x) {
        float t = clamp01(x) - 1f;
        return 1f + 2.70158f * t * t * t + 1.70158f * t * t;
    }

    /** Multiplies the alpha channel of a colour by f. */
    static int alpha(int color, float f) {
        int a = (int) (((color >>> 24) & 0xFF) * clamp01(f));
        return (color & 0x00FFFFFF) | (a << 24);
    }

    /** Per-channel (including alpha) blend. */
    static int mix(int c1, int c2, float t) {
        t = clamp01(t);
        int a = (int) lerp((c1 >>> 24) & 0xFF, (c2 >>> 24) & 0xFF, t);
        int r = (int) lerp((c1 >>> 16) & 0xFF, (c2 >>> 16) & 0xFF, t);
        int g = (int) lerp((c1 >>> 8) & 0xFF, (c2 >>> 8) & 0xFF, t);
        int b = (int) lerp(c1 & 0xFF, c2 & 0xFF, t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    // ------------------------------------------------------------------ text

    static void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align al, float spacing) {
        TP.setShader(null);
        TP.setTextSize(size);
        TP.setColor(color);
        TP.setTextAlign(al);
        TP.setLetterSpacing(spacing);
        c.drawText(s, x, y, TP);
        TP.setLetterSpacing(0f);
    }

    static void textShader(Canvas c, String s, float x, float y, float size, Shader sh, Paint.Align al, float spacing, float alphaF) {
        TP.setShader(sh);
        TP.setTextSize(size);
        TP.setColor(0xFFFFFFFF);
        TP.setAlpha((int) (255f * clamp01(alphaF)));
        TP.setTextAlign(al);
        TP.setLetterSpacing(spacing);
        c.drawText(s, x, y, TP);
        TP.setLetterSpacing(0f);
        TP.setShader(null);
        TP.setAlpha(255);
    }

    /** Soft additive glow blob. */
    static void glow(Canvas c, float cx, float cy, float radius, int color) {
        ADD.setShader(new RadialGradient(cx, cy, radius, color, alpha(color, 0f), Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, radius, ADD);
    }

    /** Animated 4-colour gradient used for the title and the credit line. */
    static Shader shimmer(float x0, float x1, float time) {
        float w = x1 - x0;
        float off = (float) Math.sin(time * 0.9f) * w * 0.35f;
        return new LinearGradient(x0 + off, 0f, x1 + off, 0f,
                new int[]{0xFF4DD2FF, 0xFFFFFFFF, 0xFFFF7AC8, 0xFF4DD2FF}, null, Shader.TileMode.MIRROR);
    }

    static void textGlow(Canvas c, String s, float x, float y, float size, int color, int glow, float glowR, Paint.Align al, float spacing) {
        TP.setShadowLayer(glowR, 0f, 0f, glow);
        text(c, s, x, y, size, color, al, spacing);
        TP.clearShadowLayer();
    }

    static float measure(String s, float size, float spacing) {
        TP.setTextSize(size);
        TP.setLetterSpacing(spacing);
        float w = TP.measureText(s);
        TP.setLetterSpacing(0f);
        return w;
    }

    // ------------------------------------------------------------------ glass panel

    static void panel(Canvas c, RectF r, float rad, float dp, float strength) {
        float sh = dp * 5f;
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setColor(alpha(0x30000000, strength));
        c.drawRoundRect(r.left, r.top + sh, r.right, r.bottom + sh, rad, rad, P);
        P.setShader(new LinearGradient(0f, r.top, 0f, r.bottom,
                new int[]{alpha(0x4BFFFFFF, strength), alpha(0x1EFFFFFF, strength), alpha(0x12FFFFFF, strength)},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, P);
        P.setShader(new LinearGradient(0f, r.top, 0f, r.top + r.height() * 0.55f,
                alpha(0x3CFFFFFF, strength), 0x00FFFFFF, Shader.TileMode.CLAMP));
        R1.set(r.left + dp, r.top + dp, r.right - dp, r.top + r.height() * 0.55f);
        c.drawRoundRect(R1, rad * 0.9f, rad * 0.9f, P);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(dp * 1.6f);
        P.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                new int[]{alpha(0xC8FFFFFF, strength), alpha(0x2AFFFFFF, strength), alpha(0x8CFFFFFF, strength)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, P);
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
    }

    // ------------------------------------------------------------------ button

    static void button(Canvas c, RectF r, String label, float press, float time, int tint, boolean primary, float dp) {
        float rad = r.height() * 0.5f;
        c.save();
        float s = 1f - 0.06f * press;
        c.scale(s, s, r.centerX(), r.centerY());
        panel(c, r, rad, dp, 1f);
        PB.reset();
        PB.addRoundRect(r, rad, rad, Path.Direction.CW);
        c.save();
        c.clipPath(PB);
        if (primary) {
            P.setShader(new LinearGradient(r.left, 0f, r.right, 0f,
                    alpha(tint, 0.85f), alpha(mix(tint, 0xFFFFFFFF, 0.3f), 0.7f), Shader.TileMode.CLAMP));
            c.drawRect(r, P);
            P.setShader(null);
        }
        float sweep = (((time + r.top * 0.002f) * 0.45f) % 2.2f) - 0.6f;
        float sx = r.left + r.width() * sweep;
        PA.reset();
        PA.moveTo(sx, r.top);
        PA.lineTo(sx + r.height() * 0.9f, r.top);
        PA.lineTo(sx + r.height() * 0.5f, r.bottom);
        PA.lineTo(sx - r.height() * 0.4f, r.bottom);
        PA.close();
        P.setShader(null);
        P.setColor(alpha(0x34FFFFFF, primary ? 1f : 0.6f));
        c.drawPath(PA, P);
        c.restore();
        text(c, label, r.centerX(), r.centerY() + r.height() * 0.15f, r.height() * 0.38f, 0xFFFFFFFF, Paint.Align.CENTER, 0.1f);
        c.restore();
    }

    // ------------------------------------------------------------------ liquid slider

    private static float surface(float x, float left, float yBase, float h, float time, float phase) {
        float k = (x - left) / h;
        return yBase + (float) Math.sin(k * 3.2f + time * 4.2f + phase) * h * 0.075f
                + (float) Math.sin(k * 1.7f - time * 2.6f + phase) * h * 0.04f;
    }

    private static void liquidPath(Path p, float fl, float fr, float bottom, float yBase, float h, float time, float phase) {
        p.reset();
        p.moveTo(fl, bottom);
        p.lineTo(fl, surface(fl, fl, yBase, h, time, phase));
        float step = Math.max(2f, h / 6f);
        for (float x = fl + step; x < fr; x += step) {
            p.lineTo(x, surface(x, fl, yBase, h, time, phase));
        }
        p.lineTo(fr, surface(fr, fl, yBase, h, time, phase));
        p.lineTo(fr, bottom);
        p.close();
    }

    /** Glass tube filled with sloshing liquid, no knob (used for progress bars). */
    static void liquidBar(Canvas c, RectF tr, float v, float time, int colA, int colB, float dp) {
        liquidBody(c, tr, tr.left + (tr.width()) * clamp01(v), time, colA, colB, dp);
    }

    private static void liquidBody(Canvas c, RectF tr, float fillRight, float time, int colA, int colB, float dp) {
        float h = tr.height();
        float rad = h * 0.5f;
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setColor(0x44000000);
        c.drawRoundRect(tr, rad, rad, P);
        PB.reset();
        PB.addRoundRect(tr, rad, rad, Path.Direction.CW);
        c.save();
        c.clipPath(PB);
        float fl = tr.left;
        float fr = Math.min(fillRight, tr.right);
        if (fr - fl > 1f) {
            float yBase = tr.top + h * 0.22f;
            liquidPath(PA, fl, fr, tr.bottom, yBase + h * 0.04f, h, time, 2.1f);
            P.setShader(new LinearGradient(tr.left, 0f, tr.right, 0f, alpha(colA, 0.45f), alpha(colB, 0.45f), Shader.TileMode.CLAMP));
            c.drawPath(PA, P);
            liquidPath(PA, fl, fr, tr.bottom, yBase, h, time, 0f);
            P.setShader(new LinearGradient(tr.left, 0f, tr.right, 0f, colA, colB, Shader.TileMode.CLAMP));
            c.drawPath(PA, P);
            P.setShader(null);
            for (int i = 0; i < 3; i++) {
                float ph = (time * 0.35f + i * 0.37f) % 1f;
                float bx = fl + (fr - fl) * (0.2f + 0.3f * i);
                float by = tr.bottom - ph * h * 0.9f;
                float br = h * (0.07f + 0.03f * i);
                if (bx < fr - br) {
                    P.setColor(alpha(0x90FFFFFF, 1f - ph));
                    c.drawCircle(bx, by, br, P);
                }
            }
        }
        R1.set(tr.left + rad, tr.top + h * 0.1f, tr.right - rad, tr.top + h * 0.3f);
        P.setShader(null);
        P.setColor(0x2CFFFFFF);
        c.drawRoundRect(R1, h * 0.1f, h * 0.1f, P);
        c.restore();
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(dp * 1.4f);
        P.setColor(0x70FFFFFF);
        c.drawRoundRect(tr, rad, rad, P);
        P.setStyle(Paint.Style.FILL);
    }

    /** Liquid-glass slider. squash (-0.4..0.4) stretches the knob in the direction it is moving. */
    static void liquidSlider(Canvas c, RectF tr, float v, float time, float squash, int colA, int colB, float dp) {
        v = clamp01(v);
        float h = tr.height();
        float rad = h * 0.5f;
        float kx = tr.left + rad + (tr.width() - h) * v;
        liquidBody(c, tr, kx, time, colA, colB, dp);
        float cy = tr.centerY();
        float kr = h * 0.95f;
        float sx = 1f + squash;
        float sy = 1f - squash * 0.65f;
        c.save();
        c.translate(kx, cy);
        c.scale(sx, sy);
        ADD.setShader(new RadialGradient(0f, 0f, kr * 2.2f, alpha(colA, 0.55f), alpha(colA, 0f), Shader.TileMode.CLAMP));
        c.drawCircle(0f, 0f, kr * 2.2f, ADD);
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setColor(0x38000000);
        c.drawCircle(0f, kr * 0.22f, kr, P);
        P.setShader(new RadialGradient(-kr * 0.3f, -kr * 0.4f, kr * 1.5f,
                new int[]{0xF2FFFFFF, 0x99D6F2FF, 0x55FFFFFF}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(0f, 0f, kr, P);
        P.setShader(new RadialGradient(0f, 0f, kr * 0.5f, alpha(colA, 0.95f), alpha(colB, 0.6f), Shader.TileMode.CLAMP));
        c.drawCircle(0f, 0f, kr * 0.42f, P);
        P.setShader(null);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(dp * 1.5f);
        P.setColor(0xB0FFFFFF);
        c.drawCircle(0f, 0f, kr, P);
        P.setStyle(Paint.Style.FILL);
        R1.set(-kr * 0.62f, -kr * 0.78f, -kr * 0.02f, -kr * 0.36f);
        P.setColor(0xB8FFFFFF);
        c.drawOval(R1, P);
        c.restore();
    }

    // ------------------------------------------------------------------ switch

    static void glassSwitch(Canvas c, RectF r, float on, float time, float dp) {
        on = clamp01(on);
        float h = r.height();
        float rad = h * 0.5f;
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setColor(0x44000000);
        c.drawRoundRect(r, rad, rad, P);
        P.setColor(mix(0x22FFFFFF, 0xCC19E3B0, on));
        c.drawRoundRect(r, rad, rad, P);
        R1.set(r.left + rad * 0.6f, r.top + h * 0.1f, r.right - rad * 0.6f, r.top + h * 0.3f);
        P.setColor(0x30FFFFFF);
        c.drawRoundRect(R1, h * 0.1f, h * 0.1f, P);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(dp * 1.4f);
        P.setColor(0x70FFFFFF);
        c.drawRoundRect(r, rad, rad, P);
        P.setStyle(Paint.Style.FILL);

        float tr = h * 0.4f;
        float x0 = r.left + rad;
        float x1 = r.right - rad;
        float cx = lerp(x0, x1, on);
        float stretch = (float) Math.sin(Math.PI * on);
        float hw = tr * (1f + 0.6f * stretch);
        float hh = tr * (1f - 0.12f * stretch);
        float cy = r.centerY();
        if (on > 0.02f) {
            ADD.setShader(new RadialGradient(cx, cy, h * 1.1f, alpha(0xFF19E3B0, 0.5f * on), 0x0019E3B0, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, h * 1.1f, ADD);
        }
        R2.set(cx - hw, cy - hh, cx + hw, cy + hh);
        P.setColor(0x38000000);
        c.drawRoundRect(R2.left, R2.top + dp * 2f, R2.right, R2.bottom + dp * 2f, hh, hh, P);
        P.setShader(new RadialGradient(cx - hw * 0.3f, cy - hh * 0.4f, Math.max(hw, hh) * 1.7f,
                new int[]{0xFFFFFFFF, 0xDDE3F6FF, 0xAACFEFFF}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(R2, hh, hh, P);
        P.setShader(null);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(dp * 1.2f);
        P.setColor(0xA0FFFFFF);
        c.drawRoundRect(R2, hh, hh, P);
        P.setStyle(Paint.Style.FILL);
        R1.set(cx - hw * 0.55f, cy - hh * 0.72f, cx + hw * 0.1f, cy - hh * 0.3f);
        P.setColor(0xCCFFFFFF);
        c.drawOval(R1, P);
    }

    // ------------------------------------------------------------------ segmented control

    static void segmented(Canvas c, RectF r, String[] labels, float pos, float time, float dp, int accent) {
        float h = r.height();
        float rad = h * 0.5f;
        float pad = h * 0.1f;
        int n = labels.length;
        float sw = (r.width() - 2f * pad) / n;
        panel(c, r, rad, dp, 0.8f);
        float frac = pos - (float) Math.floor(pos);
        float stretch = (float) Math.sin(Math.PI * frac);
        float pw = sw * (1f + 0.45f * stretch);
        float cxp = r.left + pad + sw * (pos + 0.5f);
        float pl = Math.max(r.left + pad * 0.6f, cxp - pw / 2f);
        float pr = Math.min(r.right - pad * 0.6f, cxp + pw / 2f);
        R2.set(pl, r.top + pad, pr, r.bottom - pad);
        float prad = (h - 2f * pad) * 0.5f;
        ADD.setShader(new RadialGradient(cxp, r.centerY(), sw, alpha(accent, 0.5f), alpha(accent, 0f), Shader.TileMode.CLAMP));
        c.drawCircle(cxp, r.centerY(), sw, ADD);
        P.setShader(new LinearGradient(0f, R2.top, 0f, R2.bottom,
                alpha(mix(accent, 0xFFFFFFFF, 0.35f), 0.95f), alpha(accent, 0.9f), Shader.TileMode.CLAMP));
        P.setStyle(Paint.Style.FILL);
        c.drawRoundRect(R2, prad, prad, P);
        P.setShader(null);
        P.setColor(0x44FFFFFF);
        R1.set(R2.left + prad * 0.5f, R2.top + (R2.height()) * 0.1f, R2.right - prad * 0.5f, R2.top + R2.height() * 0.42f);
        c.drawRoundRect(R1, prad * 0.5f, prad * 0.5f, P);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(dp * 1.2f);
        P.setColor(0xA0FFFFFF);
        c.drawRoundRect(R2, prad, prad, P);
        P.setStyle(Paint.Style.FILL);
        for (int i = 0; i < n; i++) {
            float wgt = clamp01(1f - Math.abs(pos - i));
            int col = mix(0xAAFFFFFF, 0xFFFFFFFF, wgt);
            text(c, labels[i], r.left + pad + sw * (i + 0.5f), r.centerY() + h * 0.12f, h * 0.31f, col, Paint.Align.CENTER, 0.04f);
        }
    }

    // ------------------------------------------------------------------ small icons

    static void star(Canvas c, float cx, float cy, float r, int fill, int edge, float rot, float dp) {
        PA.reset();
        for (int i = 0; i < 10; i++) {
            float ang = (float) (-Math.PI / 2.0 + i * Math.PI / 5.0) + rot;
            float rr = (i % 2 == 0) ? r : r * 0.46f;
            float x = cx + (float) Math.cos(ang) * rr;
            float y = cy + (float) Math.sin(ang) * rr;
            if (i == 0) {
                PA.moveTo(x, y);
            } else {
                PA.lineTo(x, y);
            }
        }
        PA.close();
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setPathEffect(new CornerPathEffect(r * 0.14f));
        P.setColor(fill);
        c.drawPath(PA, P);
        if (edge != 0) {
            P.setStyle(Paint.Style.STROKE);
            P.setStrokeWidth(dp * 1.2f);
            P.setColor(edge);
            c.drawPath(PA, P);
            P.setStyle(Paint.Style.FILL);
        }
        P.setPathEffect(null);
    }

    static void sparkle(Canvas c, float cx, float cy, float r, int color) {
        PA.reset();
        PA.moveTo(cx, cy - r);
        PA.quadTo(cx, cy, cx + r, cy);
        PA.quadTo(cx, cy, cx, cy + r);
        PA.quadTo(cx, cy, cx - r, cy);
        PA.quadTo(cx, cy, cx, cy - r);
        PA.close();
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setColor(color);
        c.drawPath(PA, P);
    }

    static void lock(Canvas c, float cx, float cy, float s, int color, float dp) {
        P.setShader(null);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(Math.max(dp * 1.6f, s * 0.14f));
        P.setColor(color);
        R1.set(cx - s * 0.32f, cy - s * 0.62f, cx + s * 0.32f, cy + s * 0.12f);
        c.drawArc(R1, 180f, 180f, false, P);
        c.drawLine(cx - s * 0.32f, cy - s * 0.25f, cx - s * 0.32f, cy - s * 0.02f, P);
        c.drawLine(cx + s * 0.32f, cy - s * 0.25f, cx + s * 0.32f, cy - s * 0.02f, P);
        P.setStyle(Paint.Style.FILL);
        R1.set(cx - s * 0.5f, cy - s * 0.05f, cx + s * 0.5f, cy + s * 0.62f);
        c.drawRoundRect(R1, s * 0.14f, s * 0.14f, P);
        P.setColor(0x66000000);
        c.drawCircle(cx, cy + s * 0.25f, s * 0.1f, P);
    }

    static void chevronLeft(Canvas c, float cx, float cy, float s, int color, float dp) {
        P.setShader(null);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(Math.max(dp * 2.2f, s * 0.2f));
        P.setStrokeCap(Paint.Cap.ROUND);
        P.setStrokeJoin(Paint.Join.ROUND);
        P.setColor(color);
        PA.reset();
        PA.moveTo(cx + s * 0.28f, cy - s * 0.5f);
        PA.lineTo(cx - s * 0.28f, cy);
        PA.lineTo(cx + s * 0.28f, cy + s * 0.5f);
        c.drawPath(PA, P);
        P.setStrokeCap(Paint.Cap.BUTT);
        P.setStyle(Paint.Style.FILL);
    }

    // ------------------------------------------------------------------ logo

    /** Hexagonal gem; sy < 0 flips it upside down (used for the coin-flip logo animation). */
    static void gem(Canvas c, float cx, float cy, float r, float sy, float time) {
        c.save();
        c.translate(cx, cy);
        c.scale(1f, sy);
        PA.reset();
        for (int i = 0; i < 6; i++) {
            float ang = (float) (Math.PI / 6.0 + i * Math.PI / 3.0);
            float x = (float) Math.cos(ang) * r;
            float y = (float) Math.sin(ang) * r;
            if (i == 0) {
                PA.moveTo(x, y);
            } else {
                PA.lineTo(x, y);
            }
        }
        PA.close();
        P.setStyle(Paint.Style.FILL);
        P.setPathEffect(new CornerPathEffect(r * 0.12f));
        P.setShader(new LinearGradient(0f, -r, 0f, r,
                new int[]{0xFFA8F6FF, 0xFF2EB8FF, 0xFF6A4DFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawPath(PA, P);
        P.setShader(null);
        c.save();
        c.clipPath(PA);
        P.setColor(0x55FFFFFF);
        PB.reset();
        PB.moveTo(-r, -r * 0.1f);
        PB.lineTo(0f, -r);
        PB.lineTo(r, -r * 0.1f);
        PB.lineTo(0f, r * 0.2f);
        PB.close();
        c.drawPath(PB, P);
        P.setColor(0x22000000);
        PB.reset();
        PB.moveTo(-r, -r * 0.1f);
        PB.lineTo(0f, r * 0.2f);
        PB.lineTo(0f, r);
        PB.lineTo(-r, r * 0.5f);
        PB.close();
        c.drawPath(PB, P);
        P.setColor(0x33FFFFFF);
        PB.reset();
        PB.moveTo(r, -r * 0.1f);
        PB.lineTo(0f, r * 0.2f);
        PB.lineTo(0f, r);
        PB.lineTo(r, r * 0.5f);
        PB.close();
        c.drawPath(PB, P);
        float sh = ((time * 0.6f) % 2f) - 0.5f;
        P.setColor(0x44FFFFFF);
        PB.reset();
        PB.moveTo(-r + sh * r * 2f, -r);
        PB.lineTo(-r + sh * r * 2f + r * 0.3f, -r);
        PB.lineTo(-r + sh * r * 2f - r * 0.2f, r);
        PB.lineTo(-r + sh * r * 2f - r * 0.5f, r);
        PB.close();
        c.drawPath(PB, P);
        c.restore();
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(r * 0.05f);
        P.setColor(0xCCFFFFFF);
        c.drawPath(PA, P);
        P.setStyle(Paint.Style.FILL);
        P.setPathEffect(null);
        c.restore();
    }

    static void logo(Canvas c, float cx, float cy, float size, float time, float dp) {
        float pulse = 0.85f + 0.15f * (float) Math.sin(time * 2f);
        ADD.setShader(new RadialGradient(cx, cy, size * 1.25f, alpha(0xFF2EB8FF, 0.55f * pulse), 0x002EB8FF, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, size * 1.25f, ADD);
        float half = size * 0.46f;
        R2.set(cx - half, cy - half, cx + half, cy + half);
        float bob = (float) Math.sin(time * 1.6f) * size * 0.02f;
        c.save();
        c.translate(0f, bob);
        panel(c, R2, size * 0.2f, dp, 1.3f);
        float flip = (float) Math.cos(time * 1.3f);
        if (Math.abs(flip) < 0.12f) {
            flip = flip < 0f ? -0.12f : 0.12f;
        }
        gem(c, cx, cy, size * 0.26f, flip, time);
        float ax = size * 0.33f;
        float asz = size * 0.075f;
        float glowK = 0.5f + 0.5f * (float) Math.sin(time * 2.6f);
        arrow(c, cx - ax, cy, asz, true, alpha(0xFFFFD54F, 0.6f + 0.4f * glowK));
        arrow(c, cx + ax, cy, asz, false, alpha(0xFFFFD54F, 1f - 0.4f * glowK));
        c.restore();
        for (int i = 0; i < 4; i++) {
            float a = time * 0.9f + i * (float) (Math.PI / 2.0);
            float rr = size * (0.66f + 0.05f * (float) Math.sin(time * 2f + i));
            float tw = 0.5f + 0.5f * (float) Math.sin(time * 3f + i * 1.7f);
            sparkle(c, cx + (float) Math.cos(a) * rr, cy + (float) Math.sin(a) * rr * 0.8f, size * (0.045f + 0.03f * tw), alpha(0xFFFFFFFF, 0.5f + 0.5f * tw));
        }
    }

    private static void arrow(Canvas c, float x, float y, float s, boolean up, int color) {
        PA.reset();
        float d = up ? -1f : 1f;
        PA.moveTo(x, y + d * s * 1.1f);
        PA.lineTo(x - s, y - d * s * 0.7f);
        PA.lineTo(x + s, y - d * s * 0.7f);
        PA.close();
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setPathEffect(new CornerPathEffect(s * 0.25f));
        P.setColor(color);
        c.drawPath(PA, P);
        P.setPathEffect(null);
    }
}
