package com.flipmatch.game;

import android.view.View;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

/**
 * Reads a tiny update.json from GitHub so you can announce updates / news without sending an APK again.
 *
 * update.json example:
 * {"versionCode": 5, "versionName": "3.2", "apkUrl": "https://github.com/USER/REPO/releases/latest",
 *  "message": "What is new in this version", "announcement": "Any news for players", "announcementId": 1}
 */
final class Updater {
    private Updater() {}

    /** TODO: put YOUR GitHub username and repo here, e.g. ayushvaitage/flipmatch */
    static final String UPDATE_URL = "https://raw.githubusercontent.com/ayushvaitage-hash/flipmatch/main/update.json";
    static final int CURRENT_VERSION = 4;
    static final String CURRENT_NAME = "3.1";

    static volatile boolean done;
    static volatile boolean ok;
    static volatile int versionCode;
    static volatile String versionName = "";
    static volatile String apkUrl = "";
    static volatile String message = "";
    static volatile String announcement = "";
    static volatile int announcementId;

    static boolean configured() {
        return !UPDATE_URL.contains("YOUR_GITHUB_USERNAME");
    }

    static boolean updateAvailable() {
        return ok && versionCode > CURRENT_VERSION;
    }

    static void check(final View host, final Runnable onDone) {
        if (!configured()) {
            done = true;
            ok = false;
            host.post(onDone);
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_URL).openConnection();
                    c.setConnectTimeout(6000);
                    c.setReadTimeout(6000);
                    BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) {
                        sb.append(line).append('\n');
                    }
                    r.close();
                    JSONObject j = new JSONObject(sb.toString());
                    versionCode = j.optInt("versionCode", 0);
                    versionName = j.optString("versionName", "");
                    apkUrl = j.optString("apkUrl", "");
                    message = j.optString("message", "");
                    announcement = j.optString("announcement", "");
                    announcementId = j.optInt("announcementId", 0);
                    ok = true;
                } catch (Exception e) {
                    ok = false;
                }
                done = true;
                host.post(onDone);
            }
        }).start();
    }
}
